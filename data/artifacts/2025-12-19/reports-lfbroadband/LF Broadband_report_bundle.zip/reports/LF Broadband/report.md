# 📊 Gerrit Project Analysis Report: LF Broadband

**Generated:** December 19, 2025 at 07:23 UTC
**Schema Version:** 1.2.0

## 📈 Global Summary

**✅ Current** commits within last 365 days
**☑️ Active** commits between 365-1095 days
**🛑 Inactive** no commits in 1095+ days

| Metric | Count | Percentage |
|--------|-------|------------|
| Total Gerrit Projects | 254 | 100% |
| Current Gerrit Projects | 32 | 12.6% |
| Active Gerrit Projects | 20 | 7.9% |
| Inactive Gerrit Projects | 200 | 78.7% |
| No Apparent Commits | 2 | 0.8% |
| Total Commits | 297 | - |
| Total Lines of Code | 1.9M | - |

## 🏢 Top Organizations

The data presented in the table below covers the past 365 days.

**Organizations Found:** 269

| Rank | Organization | Contributors | Commits | LOC | Δ LOC | Avg LOC/Commit | Unique Repositories |
|------|--------------|--------------|---------|-----|-------|----------------|---------------------|
| 1 | radisys.com | 50 | 162 | +1335229 | 2377605 | +8242.2 | 32 |
| 2 | linuxfoundation.org | 3 | 47 | -7446 | 14150 | -158.4 | 33 |
| 3 | opennetworking.org | 56 | 46 | +1412 | 1708 | +30.7 | 233 |
| 4 | bisdn.de | 4 | 24 | +50 | 1052 | +2.1 | 6 |
| 5 | netsia.com | 15 | 15 | +3522 | 8102 | +234.8 | 31 |
| 6 | github.com | 6 | 3 | +0 | 8 | +0.0 | 6 |
| 7 | 10ur.org | 1 | 0 | +0 | 0 | - | 1 |
| 8 | 14v.de | 1 | 0 | +0 | 0 | - | 1 |
| 9 | 163.com | 1 | 0 | +0 | 0 | - | 1 |
| 10 | 6wind.com | 4 | 0 | +0 | 0 | - | 1 |
| 11 | 99cloud.net | 1 | 0 | +0 | 0 | - | 1 |
| 12 | ac.jp | 1 | 0 | +0 | 0 | - | 1 |
| 13 | ac.uk | 1 | 0 | +0 | 0 | - | 1 |
| 14 | accton.com | 1 | 0 | +0 | 0 | - | 1 |
| 15 | ad.jp | 2 | 0 | +0 | 0 | - | 1 |
| 16 | adtran.com | 7 | 0 | +0 | 0 | - | 16 |
| 17 | akamai.com | 1 | 0 | +0 | 0 | - | 1 |
| 18 | alt.net | 1 | 0 | +0 | 0 | - | 1 |
| 19 | altencalsoftlabs.com | 1 | 0 | +0 | 0 | - | 1 |
| 20 | altlinux.ru | 1 | 0 | +0 | 0 | - | 1 |
| 21 | amazon.com | 5 | 0 | +0 | 0 | - | 1 |
| 22 | android.com | 9 | 0 | +0 | 0 | - | 1 |
| 23 | angband.pl | 1 | 0 | +0 | 0 | - | 1 |
| 24 | arcor.de | 1 | 0 | +0 | 0 | - | 1 |
| 25 | argon.org | 1 | 0 | +0 | 0 | - | 1 |
| 26 | aristanetworks.com | 1 | 0 | +0 | 0 | - | 1 |
| 27 | arizona.edu | 2 | 0 | +0 | 0 | - | 28 |
| 28 | arm.com | 2 | 0 | +0 | 0 | - | 2 |
| 29 | artisancomputer.com | 1 | 0 | +0 | 0 | - | 12 |
| 30 | atcorp.com | 2 | 0 | +0 | 0 | - | 1 |
| 31 | ate-mahoroba.jp | 1 | 0 | +0 | 0 | - | 1 |
| 32 | att.com | 8 | 0 | +0 | 0 | - | 13 |
| 33 | attlocal.net | 1 | 0 | +0 | 0 | - | 1 |
| 34 | bbn.com | 2 | 0 | +0 | 0 | - | 1 |
| 35 | bcsw.net | 1 | 0 | +0 | 0 | - | 1 |
| 36 | bigswitch.com | 13 | 0 | +0 | 0 | - | 1 |
| 37 | bluecatnetworks.com | 1 | 0 | +0 | 0 | - | 1 |
| 38 | bmw-carit.de | 1 | 0 | +0 | 0 | - | 1 |
| 39 | bnovc.com | 1 | 0 | +0 | 0 | - | 1 |
| 40 | boeing.com | 1 | 0 | +0 | 0 | - | 1 |
| 41 | borea.si | 1 | 0 | +0 | 0 | - | 1 |
| 42 | cablelabs.com | 1 | 0 | +0 | 0 | - | 1 |
| 43 | calsoftlabs.com | 1 | 0 | +0 | 0 | - | 1 |
| 44 | carbon.local | 1 | 0 | +0 | 0 | - | 1 |
| 45 | carroll.com | 1 | 0 | +0 | 0 | - | 1 |
| 46 | cavium.com | 1 | 0 | +0 | 0 | - | 1 |
| 47 | ccascone.net | 1 | 0 | +0 | 0 | - | 3 |
| 48 | chromium.org | 5 | 0 | +0 | 0 | - | 1 |
| 49 | ciena.com | 18 | 0 | +0 | 0 | - | 37 |
| 50 | cigtech.com | 1 | 0 | +0 | 0 | - | 2 |
| 51 | cisco.com | 1 | 0 | +0 | 0 | - | 5 |
| 52 | cloudlab.us | 9 | 0 | +0 | 0 | - | 4 |
| 53 | cluster.local | 3 | 0 | +0 | 0 | - | 3 |
| 54 | co.il | 1 | 0 | +0 | 0 | - | 1 |
| 55 | co.jp | 1 | 0 | +0 | 0 | - | 1 |
| 56 | co.nz | 1 | 0 | +0 | 0 | - | 1 |
| 57 | cochard.me | 1 | 0 | +0 | 0 | - | 1 |
| 58 | codeaurora.org | 5 | 0 | +0 | 0 | - | 1 |
| 59 | codenomicon.com | 1 | 0 | +0 | 0 | - | 1 |
| 60 | collab.net | 1 | 0 | +0 | 0 | - | 1 |
| 61 | com.br | 1 | 0 | +0 | 0 | - | 1 |
| 62 | com.cn | 2 | 0 | +0 | 0 | - | 4 |
| 63 | com.tr | 1 | 0 | +0 | 0 | - | 4 |
| 64 | com.tw | 3 | 0 | +0 | 0 | - | 3 |
| 65 | compute.internal | 1 | 0 | +0 | 0 | - | 1 |
| 66 | comstyle.com | 1 | 0 | +0 | 0 | - | 1 |
| 67 | coplanar.net | 1 | 0 | +0 | 0 | - | 1 |
| 68 | cord.lab | 1 | 0 | +0 | 0 | - | 1 |
| 69 | coredump.fr | 1 | 0 | +0 | 0 | - | 1 |
| 70 | corenova.com | 1 | 0 | +0 | 0 | - | 1 |
| 71 | crfreenet.org | 1 | 0 | +0 | 0 | - | 1 |
| 72 | cumulusnetworks.com | 13 | 0 | +0 | 0 | - | 1 |
| 73 | cyaninc.com | 1 | 0 | +0 | 0 | - | 1 |
| 74 | cyanogenmod.org | 1 | 0 | +0 | 0 | - | 1 |
| 75 | darkjames.pl | 1 | 0 | +0 | 0 | - | 1 |
| 76 | davidberard.fr | 1 | 0 | +0 | 0 | - | 1 |
| 77 | debian.(none) | 1 | 0 | +0 | 0 | - | 1 |
| 78 | debian.org | 3 | 0 | +0 | 0 | - | 1 |
| 79 | deedums.com | 1 | 0 | +0 | 0 | - | 1 |
| 80 | deltaww.com | 1 | 0 | +0 | 0 | - | 1 |
| 81 | diac24.net | 1 | 0 | +0 | 0 | - | 1 |
| 82 | digikod.net | 1 | 0 | +0 | 0 | - | 1 |
| 83 | dogonthesun.net | 1 | 0 | +0 | 0 | - | 1 |
| 84 | droidmod.org | 1 | 0 | +0 | 0 | - | 1 |
| 85 | dti2.net | 1 | 0 | +0 | 0 | - | 1 |
| 86 | dtu.dk | 1 | 0 | +0 | 0 | - | 2 |
| 87 | edge-core.com | 5 | 0 | +0 | 0 | - | 7 |
| 88 | edu.tw | 1 | 0 | +0 | 0 | - | 2 |
| 89 | emulab.net | 4 | 0 | +0 | 0 | - | 1 |
| 90 | enea.com | 1 | 0 | +0 | 0 | - | 2 |
| 91 | ericsson.com | 1 | 0 | +0 | 0 | - | 10 |
| 92 | etcnet.org | 1 | 0 | +0 | 0 | - | 1 |
| 93 | fc8-storktest.lan | 1 | 0 | +0 | 0 | - | 1 |
| 94 | finik.net | 1 | 0 | +0 | 0 | - | 1 |
| 95 | flirble.org | 1 | 0 | +0 | 0 | - | 1 |
| 96 | foobar.org | 1 | 0 | +0 | 0 | - | 1 |
| 97 | forth.gr | 1 | 0 | +0 | 0 | - | 1 |
| 98 | free-electrons.com | 1 | 0 | +0 | 0 | - | 1 |
| 99 | fujitsu.com | 3 | 0 | +0 | 0 | - | 3 |
| 100 | furukawaelectric.com | 1 | 0 | +0 | 0 | - | 2 |
| 101 | furukawalatam.com | 3 | 0 | +0 | 0 | - | 12 |
| 102 | garmin.com | 1 | 0 | +0 | 0 | - | 1 |
| 103 | gatech.edu | 1 | 0 | +0 | 0 | - | 1 |
| 104 | gmail.com | 127 | 0 | +0 | 0 | - | 145 |
| 105 | gmx.de | 1 | 0 | +0 | 0 | - | 1 |
| 106 | gmx.net | 1 | 0 | +0 | 0 | - | 1 |
| 107 | gnarf.org | 1 | 0 | +0 | 0 | - | 1 |
| 108 | google.com | 57 | 0 | +0 | 0 | - | 4 |
| 109 | googlemail.com | 1 | 0 | +0 | 0 | - | 1 |
| 110 | grahamc.com | 1 | 0 | +0 | 0 | - | 1 |
| 111 | gslab.com | 5 | 0 | +0 | 0 | - | 4 |
| 112 | hackershells.com | 1 | 0 | +0 | 0 | - | 1 |
| 113 | hcl.com | 6 | 0 | +0 | 0 | - | 5 |
| 114 | highloadlab.com | 1 | 0 | +0 | 0 | - | 1 |
| 115 | highwayman.com | 1 | 0 | +0 | 0 | - | 1 |
| 116 | hisilicon.com | 1 | 0 | +0 | 0 | - | 1 |
| 117 | hotmail.com | 2 | 0 | +0 | 0 | - | 2 |
| 118 | hpe.com | 2 | 0 | +0 | 0 | - | 1 |
| 119 | huawei.com | 1 | 0 | +0 | 0 | - | 1 |
| 120 | igmo.org | 1 | 0 | +0 | 0 | - | 1 |
| 121 | iki.fi | 1 | 0 | +0 | 0 | - | 1 |
| 122 | inango-systems.com | 1 | 0 | +0 | 0 | - | 1 |
| 123 | indiana.edu | 1 | 0 | +0 | 0 | - | 1 |
| 124 | inex.ie | 1 | 0 | +0 | 0 | - | 1 |
| 125 | infosys.com | 16 | 0 | +0 | 0 | - | 38 |
| 126 | inkylabs.com | 1 | 0 | +0 | 0 | - | 1 |
| 127 | instituut.net | 1 | 0 | +0 | 0 | - | 1 |
| 128 | intel.com | 32 | 0 | +0 | 0 | - | 45 |
| 129 | intercloud.net | 1 | 0 | +0 | 0 | - | 1 |
| 130 | ipacct.com | 1 | 0 | +0 | 0 | - | 1 |
| 131 | iptel.by | 1 | 0 | +0 | 0 | - | 1 |
| 132 | iu.edu | 1 | 0 | +0 | 0 | - | 1 |
| 133 | jabil.com | 1 | 0 | +0 | 0 | - | 3 |
| 134 | jakma.org | 1 | 0 | +0 | 0 | - | 1 |
| 135 | joshtriplett.org | 1 | 0 | +0 | 0 | - | 1 |
| 136 | joyent.com | 1 | 0 | +0 | 0 | - | 1 |
| 137 | jussieu.fr | 2 | 0 | +0 | 0 | - | 1 |
| 138 | kailashs-macbook-pro.local | 1 | 0 | +0 | 0 | - | 1 |
| 139 | klfree.net | 1 | 0 | +0 | 0 | - | 1 |
| 140 | kroenchenstadt.de | 1 | 0 | +0 | 0 | - | 1 |
| 141 | labn.net | 1 | 0 | +0 | 0 | - | 1 |
| 142 | lge.com | 1 | 0 | +0 | 0 | - | 1 |
| 143 | link-me.it | 1 | 0 | +0 | 0 | - | 1 |
| 144 | localhost.localdomain | 2 | 0 | +0 | 0 | - | 1 |
| 145 | ltts.com | 1 | 0 | +0 | 0 | - | 1 |
| 146 | luffy.cx | 1 | 0 | +0 | 0 | - | 1 |
| 147 | lycos.com | 1 | 0 | +0 | 0 | - | 1 |
| 148 | mail.ru | 1 | 0 | +0 | 0 | - | 1 |
| 149 | mattakis.com | 1 | 0 | +0 | 0 | - | 1 |
| 150 | mcords-macbook-pro.local | 1 | 0 | +0 | 0 | - | 1 |
| 151 | medallia.com | 1 | 0 | +0 | 0 | - | 1 |
| 152 | mellanox.com | 2 | 0 | +0 | 0 | - | 3 |
| 153 | mit.edu | 1 | 0 | +0 | 0 | - | 1 |
| 154 | mogulmouse.net | 1 | 0 | +0 | 0 | - | 1 |
| 155 | morganstanley.com | 1 | 0 | +0 | 0 | - | 1 |
| 156 | motorola.com | 1 | 0 | +0 | 0 | - | 1 |
| 157 | myyearbook.com | 1 | 0 | +0 | 0 | - | 1 |
| 158 | nec.com | 1 | 0 | +0 | 0 | - | 3 |
| 159 | networkplumber.org | 1 | 0 | +0 | 0 | - | 1 |
| 160 | nfware.com | 1 | 0 | +0 | 0 | - | 1 |
| 161 | nicira.com | 1 | 0 | +0 | 0 | - | 1 |
| 162 | nokia.com | 2 | 0 | +0 | 0 | - | 4 |
| 163 | northforgeinc.com | 2 | 0 | +0 | 0 | - | 2 |
| 164 | nowhere.ws | 1 | 0 | +0 | 0 | - | 1 |
| 165 | null.com | 1 | 0 | +0 | 0 | - | 2 |
| 166 | nvidia.com | 1 | 0 | +0 | 0 | - | 1 |
| 167 | onfs-macbook-pro-2.local | 1 | 0 | +0 | 0 | - | 1 |
| 168 | onlab.us | 26 | 0 | +0 | 0 | - | 99 |
| 169 | ooyala.com | 1 | 0 | +0 | 0 | - | 1 |
| 170 | open.ch | 2 | 0 | +0 | 0 | - | 1 |
| 171 | opencord.org | 1 | 0 | +0 | 0 | - | 15 |
| 172 | opennetwokring.org | 1 | 0 | +0 | 0 | - | 1 |
| 173 | opennetworking.org” | 1 | 0 | +0 | 0 | - | 1 |
| 174 | opennetworkingorg | 1 | 0 | +0 | 0 | - | 1 |
| 175 | opensourcerouting.org | 6 | 0 | +0 | 0 | - | 1 |
| 176 | opteya.com | 1 | 0 | +0 | 0 | - | 1 |
| 177 | oracle.com | 1 | 0 | +0 | 0 | - | 1 |
| 178 | orange.com | 1 | 0 | +0 | 0 | - | 1 |
| 179 | org.tw | 1 | 0 | +0 | 0 | - | 10 |
| 180 | org.ua | 1 | 0 | +0 | 0 | - | 1 |
| 181 | ota.si | 1 | 0 | +0 | 0 | - | 1 |
| 182 | packetconsulting.pl | 1 | 0 | +0 | 0 | - | 1 |
| 183 | parlakisik.com | 1 | 0 | +0 | 0 | - | 5 |
| 184 | parrot.com | 3 | 0 | +0 | 0 | - | 1 |
| 185 | pch.net | 1 | 0 | +0 | 0 | - | 1 |
| 186 | pld-linux.org | 1 | 0 | +0 | 0 | - | 1 |
| 187 | pobox.com | 1 | 0 | +0 | 0 | - | 1 |
| 188 | poolp.org | 1 | 0 | +0 | 0 | - | 1 |
| 189 | princeton.edu | 10 | 0 | +0 | 0 | - | 4 |
| 190 | princeton.org | 1 | 0 | +0 | 0 | - | 1 |
| 191 | prod1.menlo | 1 | 0 | +0 | 0 | - | 1 |
| 192 | psc.edu | 1 | 0 | +0 | 0 | - | 1 |
| 193 | qq.com | 1 | 0 | +0 | 0 | - | 1 |
| 194 | qrator.net | 1 | 0 | +0 | 0 | - | 1 |
| 195 | quagga.net | 2 | 0 | +0 | 0 | - | 1 |
| 196 | raedomain.com | 1 | 0 | +0 | 0 | - | 1 |
| 197 | redhat.com | 1 | 0 | +0 | 0 | - | 1 |
| 198 | reichmann.nl | 1 | 0 | +0 | 0 | - | 1 |
| 199 | reply.it | 1 | 0 | +0 | 0 | - | 1 |
| 200 | ringlet.net | 1 | 0 | +0 | 0 | - | 1 |
| 201 | ripe.net | 1 | 0 | +0 | 0 | - | 1 |
| 202 | ruggedcom.com | 1 | 0 | +0 | 0 | - | 1 |
| 203 | rustyeddy.com | 1 | 0 | +0 | 0 | - | 1 |
| 204 | sackheads.org | 1 | 0 | +0 | 0 | - | 1 |
| 205 | sandia.gov | 1 | 0 | +0 | 0 | - | 1 |
| 206 | sapans-macbook-pro.local | 1 | 0 | +0 | 0 | - | 1 |
| 207 | saville.com | 1 | 0 | +0 | 0 | - | 1 |
| 208 | seblu.net | 1 | 0 | +0 | 0 | - | 1 |
| 209 | secunet.com | 1 | 0 | +0 | 0 | - | 1 |
| 210 | securecomputing.com | 1 | 0 | +0 | 0 | - | 1 |
| 211 | sevone.com | 1 | 0 | +0 | 0 | - | 1 |
| 212 | seznam.cz | 1 | 0 | +0 | 0 | - | 1 |
| 213 | sholland.org | 1 | 0 | +0 | 0 | - | 1 |
| 214 | shrubbery.net | 1 | 0 | +0 | 0 | - | 1 |
| 215 | siemens.com | 1 | 0 | +0 | 0 | - | 1 |
| 216 | silverton.gr | 1 | 0 | +0 | 0 | - | 1 |
| 217 | sk.com | 1 | 0 | +0 | 0 | - | 1 |
| 218 | slimroms.net | 1 | 0 | +0 | 0 | - | 1 |
| 219 | sonic.net | 1 | 0 | +0 | 0 | - | 1 |
| 220 | sony.com | 1 | 0 | +0 | 0 | - | 1 |
| 221 | sonyericsson.com | 4 | 0 | +0 | 0 | - | 1 |
| 222 | sonymobile.com | 5 | 0 | +0 | 0 | - | 1 |
| 223 | sophos.com | 2 | 0 | +0 | 0 | - | 1 |
| 224 | sproute.com | 1 | 0 | +0 | 0 | - | 1 |
| 225 | stanford.edu | 7 | 0 | +0 | 0 | - | 13 |
| 226 | stericsson.com | 1 | 0 | +0 | 0 | - | 1 |
| 227 | sterlite.com | 2 | 0 | +0 | 0 | - | 3 |
| 228 | stingr.net | 1 | 0 | +0 | 0 | - | 1 |
| 229 | sun.com | 2 | 0 | +0 | 0 | - | 1 |
| 230 | suse.de | 1 | 0 | +0 | 0 | - | 1 |
| 231 | sysnetsistemi.it | 1 | 0 | +0 | 0 | - | 1 |
| 232 | tcs.com | 2 | 0 | +0 | 0 | - | 3 |
| 233 | ted-4.local | 1 | 0 | +0 | 0 | - | 1 |
| 234 | ted-intel.local | 1 | 0 | +0 | 0 | - | 1 |
| 235 | ted.local | 1 | 0 | +0 | 0 | - | 1 |
| 236 | tellabs.com | 1 | 0 | +0 | 0 | - | 1 |
| 237 | telstra.com | 1 | 0 | +0 | 0 | - | 1 |
| 238 | ti82.(none) | 1 | 0 | +0 | 0 | - | 1 |
| 239 | tomh.org | 1 | 0 | +0 | 0 | - | 1 |
| 240 | toroki.com | 1 | 0 | +0 | 0 | - | 1 |
| 241 | transmode.se | 1 | 0 | +0 | 0 | - | 1 |
| 242 | tu-darmstadt.de | 1 | 0 | +0 | 0 | - | 1 |
| 243 | tu-ilmenau.de | 1 | 0 | +0 | 0 | - | 1 |
| 244 | ubuntu-vm-1.(none) | 2 | 0 | +0 | 0 | - | 1 |
| 245 | univ-paris-diderot.fr | 1 | 0 | +0 | 0 | - | 1 |
| 246 | uoc.gr | 1 | 0 | +0 | 0 | - | 1 |
| 247 | uoregon.edu | 1 | 0 | +0 | 0 | - | 1 |
| 248 | varna.net | 1 | 0 | +0 | 0 | - | 1 |
| 249 | verivue.com | 1 | 0 | +0 | 0 | - | 1 |
| 250 | viavisolutions.com | 1 | 0 | +0 | 0 | - | 5 |
| 251 | vicci.org | 1 | 0 | +0 | 0 | - | 1 |
| 252 | villa-technologies.com | 1 | 0 | +0 | 0 | - | 1 |
| 253 | vio.us | 1 | 0 | +0 | 0 | - | 1 |
| 254 | voltha | 1 | 0 | +0 | 0 | - | 1 |
| 255 | vyatta.com | 4 | 0 | +0 | 0 | - | 1 |
| 256 | windriver.com | 3 | 0 | +0 | 0 | - | 2 |
| 257 | windstream.com | 1 | 0 | +0 | 0 | - | 1 |
| 258 | wkwflp.org | 1 | 0 | +0 | 0 | - | 1 |
| 259 | wq.cz | 1 | 0 | +0 | 0 | - | 1 |
| 260 | wrs.com | 1 | 0 | +0 | 0 | - | 1 |
| 261 | xevo.com | 1 | 0 | +0 | 0 | - | 1 |
| 262 | xiaomi.com | 1 | 0 | +0 | 0 | - | 1 |
| 263 | xip.at | 1 | 0 | +0 | 0 | - | 1 |
| 264 | yahoo.fr | 3 | 0 | +0 | 0 | - | 2 |
| 265 | yandex-team.ru | 2 | 0 | +0 | 0 | - | 1 |
| 266 | yandex.ru | 2 | 0 | +0 | 0 | - | 1 |
| 267 | yath.de | 1 | 0 | +0 | 0 | - | 1 |
| 268 | zhaw.ch | 1 | 0 | +0 | 0 | - | 1 |
| 269 | zooglr.com | 1 | 0 | +0 | 0 | - | 1 |

## 👥 Top Contributors



The data presented in the table below covers the past 365 days.



**Contributors Found:** 820

| Rank | Contributor | Commits | LOC | Δ LOC | Avg LOC/Commit | Repositories | Organization |
|------|-------------|---------|-----|-------|----------------|--------------|--------------|
| 1 | Eric Ball | 47 | -7446 | 14150 | -158.4 | 24 | linuxfoundation.org |
| 2 | Jenkins | 46 | +1412 | 1708 | +30.7 | 12 | opennetworking.org |
| 3 | akashreddyk | 27 | +204243 | 393399 | +7564.6 | 11 | radisys.com |
| 4 | bseeniva | 19 | +171 | 779 | +9.0 | 5 | radisys.com |
| 5 | Abhay Kumar | 16 | +1051095 | 1819527 | +65693.4 | 6 | radisys.com |
| 6 | mgouda | 16 | +62680 | 120972 | +3917.5 | 6 | radisys.com |
| 7 | Sridhar Ravindra | 16 | +934 | 2748 | +58.4 | 8 | radisys.com |
| 8 | abhayk | 15 | +175 | 357 | +11.7 | 9 | radisys.com |
| 9 | gst | 14 | +191 | 437 | +13.6 | 2 | radisys.com |
| 10 | Cristina de Francisco | 14 | +50 | 824 | +3.6 | 4 | bisdn.de |
| 11 | praneeth.nalmas | 13 | +2384 | 14258 | +183.4 | 11 | radisys.com |
| 12 | Mahir Gunyel | 11 | +3538 | 8026 | +321.6 | 24 | netsia.com |
| 13 | balaji.nagarajan | 9 | +466 | 4906 | +51.8 | 5 | radisys.com |
| 14 | Amaia | 9 | +0 | 228 | +0.0 | 3 | bisdn.de |
| 15 | Abhilash Laxmeshwar | 8 | +909 | 2449 | +113.6 | 11 | radisys.com |
| 16 | Serkant Uluderya | 4 | -16 | 76 | -4.0 | 11 | netsia.com |
| 17 | rbodapat | 4 | -23 | 121 | -5.8 | 1 | radisys.com |
| 18 | dependabot[bot] | 3 | +0 | 8 | +0.0 | 1 | github.com |
| 19 | Amit Ghosh | 2 | +11929 | 17505 | +5964.5 | 13 | radisys.com |
| 20 | Akash Soni | 2 | +73 | 135 | +36.5 | 8 | radisys.com |
| 21 | Nandita Biradar | 1 | +2 | 12 | +2.0 | 2 | radisys.com |
| 22 | Roger Luethi | 1 | +0 | 0 | +0.0 | 3 | bisdn.de |
| 23 | A R Karthick | 0 | +0 | 0 | - | 7 | ciena.com |
| 24 | A R Karthick | 0 | +0 | 0 | - | 1 | gmail.com |
| 25 | A R. Karthick | 0 | +0 | 0 | - | 1 | cyaninc.com |
| 26 | Aaron Kruglikov | 0 | +0 | 0 | - | 1 | fujitsu.com |
| 27 | Abhilash Endurthi | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 28 | Adam Borowski | 0 | +0 | 0 | - | 1 | angband.pl |
| 29 | Aharoni, Pavel (pa0916) | 0 | +0 | 0 | - | 1 | att.com |
| 30 | Ajay Lotan Thakur | 0 | +0 | 0 | - | 3 | gmail.com |
| 31 | Ajay Lotan Thakur | 0 | +0 | 0 | - | 4 | intel.com |
| 32 | Akshay Verma | 0 | +0 | 0 | - | 1 | gmail.com |
| 33 | Alex Yashchuk | 0 | +0 | 0 | - | 1 | cavium.com |
| 34 | Alexander Bird | 0 | +0 | 0 | - | 1 | gmail.com |
| 35 | Alexandre Boeglin | 0 | +0 | 0 | - | 1 | parrot.com |
| 36 | Alexandre Chappuis | 0 | +0 | 0 | - | 1 | open.ch |
| 37 | Alexandre Garnier | 0 | +0 | 0 | - | 1 | gmail.com |
| 38 | Alexis Fasquel | 0 | +0 | 0 | - | 1 | pch.net |
| 39 | Ali "The Bomb" Al-Shabibi | 0 | +0 | 0 | - | 29 | onlab.us |
| 40 | Ali Utku Selen | 0 | +0 | 0 | - | 1 | sonyericsson.com |
| 41 | Amir Zeidner | 0 | +0 | 0 | - | 1 | mellanox.com |
| 42 | Amit Ghosh | 0 | +0 | 0 | - | 4 | radisys.com |
| 43 | Amit Wankhede | 0 | +0 | 0 | - | 1 | gslab.com |
| 44 | Amol Jaikar | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 45 | Amritha Nambiar | 0 | +0 | 0 | - | 1 | intel.com |
| 46 | Anand S Katti | 0 | +0 | 0 | - | 1 | radisys.com |
| 47 | Anatol Pomazau | 0 | +0 | 0 | - | 1 | google.com |
| 48 | Anatol Pomozov | 0 | +0 | 0 | - | 1 | gmail.com |
| 49 | Andrea Campanella | 0 | +0 | 0 | - | 21 | intel.com |
| 50 | Andrea Campanella | 0 | +0 | 0 | - | 44 | opennetworking.org |
| 51 | Andrea Campanella | 0 | +0 | 0 | - | 1 | opennetwokring.org |
| 52 | Andrea Campanella | 0 | +0 | 0 | - | 8 | onlab.us |
| 53 | Andrea Speranza | 0 | +0 | 0 | - | 2 | gmail.com |
| 54 | Andreas Pantelopoulos | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 55 | Andrei Warkentin | 0 | +0 | 0 | - | 1 | motorola.com |
| 56 | Andrej Ota | 0 | +0 | 0 | - | 1 | ota.si |
| 57 | Andrew Certain | 0 | +0 | 0 | - | 1 | amazon.com |
| 58 | Andrew J. Schorr | 0 | +0 | 0 | - | 1 | princeton.edu |
| 59 | Andrew J. Schorr | 0 | +0 | 0 | - | 1 | ti82.(none) |
| 60 | Andrew Wheeler | 0 | +0 | 0 | - | 1 | gmail.com |
| 61 | Andrew Wheeler | 0 | +0 | 0 | - | 1 | igmo.org |
| 62 | Andrey Pozolotin | 0 | +0 | 0 | - | 19 | gmail.com |
| 63 | Android Code Review | 0 | +0 | 0 | - | 1 | android.com |
| 64 | Andy Bavier | 0 | +0 | 0 | - | 30 | opennetworking.org |
| 65 | Andy Bavier | 0 | +0 | 0 | - | 52 | onlab.us |
| 66 | Andy Bavier | 0 | +0 | 0 | - | 2 | princeton.edu |
| 67 | Ang Way Chuang | 0 | +0 | 0 | - | 1 | gmail.com |
| 68 | Anil Kumar Sanka | 0 | +0 | 0 | - | 1 | ciena.com |
| 69 | Ankur Upadhyaya | 0 | +0 | 0 | - | 2 | intel.com |
| 70 | Ankur Upadhyaya | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 71 | Anthony | 0 | +0 | 0 | - | 1 | bnovc.com |
| 72 | Anthony King | 0 | +0 | 0 | - | 1 | slimroms.net |
| 73 | Anthony Newnam | 0 | +0 | 0 | - | 1 | garmin.com |
| 74 | Anthony Russello | 0 | +0 | 0 | - | 1 | gmail.com |
| 75 | Arda Demir | 0 | +0 | 0 | - | 3 | gmail.com |
| 76 | Ari Saha | 0 | +0 | 0 | - | 1 | att.com |
| 77 | Arjun E K | 0 | +0 | 0 | - | 5 | infosys.com |
| 78 | Arpit Agarwal | 0 | +0 | 0 | - | 2 | gmail.com |
| 79 | Arrobo, Gabriel | 0 | +0 | 0 | - | 3 | intel.com |
| 80 | Arthur Syu | 0 | +0 | 0 | - | 1 | com.tw |
| 81 | Arun Arora | 0 | +0 | 0 | - | 2 | hcl.com |
| 82 | Avneesh Sachdev | 0 | +0 | 0 | - | 1 | sproute.com |
| 83 | Avneesh Sachdev | 0 | +0 | 0 | - | 1 | opensourcerouting.org |
| 84 | Ayan Banerjee | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 85 | Aymen Bouaziz | 0 | +0 | 0 | - | 1 | parrot.com |
| 86 | AyumuUeha | 0 | +0 | 0 | - | 1 | fujitsu.com |
| 87 | Badhrinath Padmanabhan | 0 | +0 | 0 | - | 3 | gmail.com |
| 88 | Badhrinath Padmanabhan | 0 | +0 | 0 | - | 2 | intel.com |
| 89 | Balaji | 0 | +0 | 0 | - | 1 | gmail.com |
| 90 | Baris Ertas | 0 | +0 | 0 | - | 1 | netsia.com |
| 91 | Barry Friedman | 0 | +0 | 0 | - | 1 | google.com |
| 92 | Bartek Kania | 0 | +0 | 0 | - | 1 | gnarf.org |
| 93 | Baruch Siach | 0 | +0 | 0 | - | 1 | co.il |
| 94 | Bavier, Andy | 0 | +0 | 0 | - | 1 | intel.com |
| 95 | Beerappa S M | 0 | +0 | 0 | - | 1 | radisys.com |
| 96 | Ben Komalo | 0 | +0 | 0 | - | 1 | google.com |
| 97 | Ben Pfaff | 0 | +0 | 0 | - | 1 | nicira.com |
| 98 | Bertrand SIMONNET | 0 | +0 | 0 | - | 1 | google.com |
| 99 | Boian Bonev | 0 | +0 | 0 | - | 1 | ipacct.com |
| 100 | Brad Smith | 0 | +0 | 0 | - | 1 | comstyle.com |
| 101 | Brandon Heller | 0 | +0 | 0 | - | 1 | stanford.edu |
| 102 | Brett Ciphery | 0 | +0 | 0 | - | 1 | windriver.com |
| 103 | Brian Bennett | 0 | +0 | 0 | - | 1 | joyent.com |
| 104 | Brian Harring | 0 | +0 | 0 | - | 1 | google.com |
| 105 | Brian Harring | 0 | +0 | 0 | - | 1 | chromium.org |
| 106 | Brian Harring | 0 | +0 | 0 | - | 1 | intel.com |
| 107 | Brian Lube | 0 | +0 | 0 | - | 1 | windstream.com |
| 108 | Brian O'Connor | 0 | +0 | 0 | - | 32 | opennetworking.org |
| 109 | Brian O'Connor | 0 | +0 | 0 | - | 8 | onlab.us |
| 110 | Brian Stanke | 0 | +0 | 0 | - | 3 | ciena.com |
| 111 | Brian Utterback | 0 | +0 | 0 | - | 1 | oracle.com |
| 112 | Brian Waters | 0 | +0 | 0 | - | 1 | wkwflp.org |
| 113 | Bryan Jacobs | 0 | +0 | 0 | - | 1 | gmail.com |
| 114 | Burak Gurdag | 0 | +0 | 0 | - | 2 | netsia.com |
| 115 | CROSS | 0 | +0 | 0 | - | 1 | codenomicon.com |
| 116 | Carlos Aguado | 0 | +0 | 0 | - | 1 | gmail.com |
| 117 | Carmelo Cascone | 0 | +0 | 0 | - | 20 | opennetworking.org |
| 118 | Carmelo Cascone | 0 | +0 | 0 | - | 3 | ccascone.net |
| 119 | Cassidy Burden | 0 | +0 | 0 | - | 1 | codeaurora.org |
| 120 | Cezary Baginski | 0 | +0 | 0 | - | 1 | gmail.com |
| 121 | Chad Jones | 0 | +0 | 0 | - | 1 | google.com |
| 122 | Chaitrashree G S | 0 | +0 | 0 | - | 4 | radisys.com |
| 123 | Chandrakanth Nalkudre Gowda | 0 | +0 | 0 | - | 1 | radisys.com |
| 124 | Changcheng Xiao | 0 | +0 | 0 | - | 1 | google.com |
| 125 | Charles Chan | 0 | +0 | 0 | - | 14 | gmail.com |
| 126 | Charles Chan | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 127 | Charles Chan | 0 | +0 | 0 | - | 2 | intel.com |
| 128 | Che-Liang Chiou | 0 | +0 | 0 | - | 1 | google.com |
| 129 | Chetan Gaonker | 0 | +0 | 0 | - | 1 | ciena.com |
| 130 | Chetan Gaonker | 0 | +0 | 0 | - | 1 | calsoftlabs.com |
| 131 | ChetanGaonker | 0 | +0 | 0 | - | 1 | ciena.com |
| 132 | Cheuk Leung | 0 | +0 | 0 | - | 1 | gmail.com |
| 133 | Chip Boling | 0 | +0 | 0 | - | 1 | bcsw.net |
| 134 | Chip Boling | 0 | +0 | 0 | - | 1 | adtran.com |
| 135 | Chirayu Desai | 0 | +0 | 0 | - | 1 | gmail.com |
| 136 | Chirayu Desai | 0 | +0 | 0 | - | 1 | cyanogenmod.org |
| 137 | Chris AtLee | 0 | +0 | 0 | - | 1 | gmail.com |
| 138 | Chris Caputo | 0 | +0 | 0 | - | 1 | alt.net |
| 139 | Chris Hall | 0 | +0 | 0 | - | 1 | highwayman.com |
| 140 | Chris Luke | 0 | +0 | 0 | - | 1 | flirble.org |
| 141 | Chris Wolfe | 0 | +0 | 0 | - | 1 | chromium.org |
| 142 | Christer Fletcher | 0 | +0 | 0 | - | 1 | sonyericsson.com |
| 143 | Christian Dickmann | 0 | +0 | 0 | - | 1 | gmail.com |
| 144 | Christian Franke | 0 | +0 | 0 | - | 1 | opensourcerouting.org |
| 145 | Christian Franke | 0 | +0 | 0 | - | 1 | nowhere.ws |
| 146 | Christian Hammers | 0 | +0 | 0 | - | 1 | debian.org |
| 147 | Christian Koestlin | 0 | +0 | 0 | - | 1 | gmail.com |
| 148 | Ciprian Barbu | 0 | +0 | 0 | - | 2 | enea.com |
| 149 | Colin Cross | 0 | +0 | 0 | - | 1 | android.com |
| 150 | Colin Petrie | 0 | +0 | 0 | - | 1 | ripe.net |
| 151 | Conley Owens | 0 | +0 | 0 | - | 1 | android.com |
| 152 | Craig Lutgen | 0 | +0 | 0 | - | 1 | tellabs.com |
| 153 | Daichi Ueura | 0 | +0 | 0 | - | 1 | sony.com |
| 154 | Dan Morrill | 0 | +0 | 0 | - | 1 | google.com |
| 155 | Dan Sandler | 0 | +0 | 0 | - | 1 | android.com |
| 156 | Dan Talayco | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 157 | Dan Talayco | 0 | +0 | 0 | - | 1 | stanford.edu |
| 158 | Dan Talayco | 0 | +0 | 0 | - | 1 | stanford.edu |
| 159 | Dan Talayco | 0 | +0 | 0 | - | 1 | mogulmouse.net |
| 160 | Dan Willemsen | 0 | +0 | 0 | - | 1 | google.com |
| 161 | Dan Willemsen | 0 | +0 | 0 | - | 1 | nvidia.com |
| 162 | Dana Dahlstrom | 0 | +0 | 0 | - | 1 | google.com |
| 163 | Daniel Kozlowski | 0 | +0 | 0 | - | 1 | sevone.com |
| 164 | Daniel Ng | 0 | +0 | 0 | - | 1 | lycos.com |
| 165 | Daniel Park | 0 | +0 | 0 | - | 1 | sk.com |
| 166 | Daniel Sandler | 0 | +0 | 0 | - | 1 | google.com |
| 167 | Daniel Walton | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 168 | Daniel Walton | 0 | +0 | 0 | - | 1 | gmail.com |
| 169 | Daniele Moro | 0 | +0 | 0 | - | 31 | opennetworking.org |
| 170 | Daniele Moro | 0 | +0 | 0 | - | 1 | intel.com |
| 171 | Daniele Rossi | 0 | +0 | 0 | - | 3 | hcl.com |
| 172 | Dave Borowitz | 0 | +0 | 0 | - | 1 | google.com |
| 173 | David 'Digit' Turner | 0 | +0 | 0 | - | 1 | google.com |
| 174 | David Aguilar | 0 | +0 | 0 | - | 1 | gmail.com |
| 175 | David BÉRARD | 0 | +0 | 0 | - | 1 | davidberard.fr |
| 176 | David Ferguson | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 177 | David Holmer | 0 | +0 | 0 | - | 1 | gmail.com |
| 178 | David James | 0 | +0 | 0 | - | 1 | google.com |
| 179 | David K. Bainbridge | 0 | +0 | 0 | - | 33 | ciena.com |
| 180 | David Lamparter | 0 | +0 | 0 | - | 1 | opensourcerouting.org |
| 181 | David Lamparter | 0 | +0 | 0 | - | 1 | diac24.net |
| 182 | David Payne | 0 | +0 | 0 | - | 1 | gmail.com |
| 183 | David Pursehouse | 0 | +0 | 0 | - | 1 | collab.net |
| 184 | David Pursehouse | 0 | +0 | 0 | - | 1 | sonymobile.com |
| 185 | David Riley | 0 | +0 | 0 | - | 1 | google.com |
| 186 | David Ward | 0 | +0 | 0 | - | 1 | mit.edu |
| 187 | David Young | 0 | +0 | 0 | - | 1 | pobox.com |
| 188 | Denil Vira | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 189 | Denis Ovsienko | 0 | +0 | 0 | - | 1 | yandex.ru |
| 190 | Denis Ovsienko | 0 | +0 | 0 | - | 1 | etcnet.org |
| 191 | Denis Ovsienko | 0 | +0 | 0 | - | 1 | org.ua |
| 192 | Dinesh Belwalkar | 0 | +0 | 0 | - | 7 | gmail.com |
| 193 | Dinesh Dutt | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 194 | Dmitrij Tejblum | 0 | +0 | 0 | - | 1 | yandex-team.ru |
| 195 | Dmitry Fink | 0 | +0 | 0 | - | 1 | finik.net |
| 196 | Dmitry Popov | 0 | +0 | 0 | - | 1 | highloadlab.com |
| 197 | Don Newton | 0 | +0 | 0 | - | 2 | att.com |
| 198 | Don Newton | 0 | +0 | 0 | - | 1 | gmail.com |
| 199 | Donald Sharp | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 200 | Doug Anderson | 0 | +0 | 0 | - | 1 | chromium.org |
| 201 | Doug Anderson | 0 | +0 | 0 | - | 1 | google.com |
| 202 | Doug VanLeuven | 0 | +0 | 0 | - | 1 | sonic.net |
| 203 | Doyoung Lee | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 204 | Dusan Klinec | 0 | +0 | 0 | - | 1 | gmail.com |
| 205 | Dylan Deng | 0 | +0 | 0 | - | 1 | gmail.com |
| 206 | Dylan Hall | 0 | +0 | 0 | - | 1 | deedums.com |
| 207 | Dāvis Mosāns | 0 | +0 | 0 | - | 1 | gmail.com |
| 208 | Ed Swierk | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 209 | Elena Stoeva | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 210 | Eli Ribble | 0 | +0 | 0 | - | 1 | google.com |
| 211 | Elia Battiston | 0 | +0 | 0 | - | 14 | opennetworking.org |
| 212 | Elia Battiston | 0 | +0 | 0 | - | 2 | radisys.com |
| 213 | Emrehan UZUN | 0 | +0 | 0 | - | 1 | netsia.com |
| 214 | Ereth McKnight-MacNeil | 0 | +0 | 0 | - | 1 | google.com |
| 215 | Erwan Mahe | 0 | +0 | 0 | - | 1 | intel.com |
| 216 | Esin Karaman | 0 | +0 | 0 | - | 7 | netsia.com |
| 217 | Etan Cohen | 0 | +0 | 0 | - | 1 | google.com |
| 218 | Everton Marques | 0 | +0 | 0 | - | 1 | gmail.com |
| 219 | Evgeny Uskov | 0 | +0 | 0 | - | 1 | qrator.net |
| 220 | Fatemeh Rouzbeh | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 221 | Fatemeh Rouzbeh | 0 | +0 | 0 | - | 1 | intel.com |
| 222 | Feng Lu | 0 | +0 | 0 | - | 1 | 6wind.com |
| 223 | Fernando Soto | 0 | +0 | 0 | - | 1 | bluecatnetworks.com |
| 224 | Ficus Kirkpatrick | 0 | +0 | 0 | - | 1 | android.com |
| 225 | Flavio Castro | 0 | +0 | 0 | - | 1 | gmail.com |
| 226 | Flavio Castro | 0 | +0 | 0 | - | 1 | onlab.us |
| 227 | Flavio Castro | 0 | +0 | 0 | - | 1 | gmail.com |
| 228 | Flavio Castro | 0 | +0 | 0 | - | 1 | att.com |
| 229 | Florian Vallee | 0 | +0 | 0 | - | 1 | gmail.com |
| 230 | Francesco Dolcini | 0 | +0 | 0 | - | 1 | sysnetsistemi.it |
| 231 | Fredrik Berggren | 0 | +0 | 0 | - | 1 | gmail.com |
| 232 | Fridolin Siegmund | 0 | +0 | 0 | - | 1 | tu-darmstadt.de |
| 233 | Fritz Reichmann | 0 | +0 | 0 | - | 1 | reichmann.nl |
| 234 | Gabe Black | 0 | +0 | 0 | - | 5 | viavisolutions.com |
| 235 | Gabe Black | 0 | +0 | 0 | - | 1 | chromium.org |
| 236 | Gamze Abaka | 0 | +0 | 0 | - | 12 | netsia.com |
| 237 | Ganesh Bhure | 0 | +0 | 0 | - | 2 | sterlite.com |
| 238 | Ganeshbabu | 0 | +0 | 0 | - | 1 | hcl.com |
| 239 | Gautam Kumar | 0 | +0 | 0 | - | 1 | amazon.com |
| 240 | Gayathri.Selvan | 0 | +0 | 0 | - | 2 | infosys.com |
| 241 | Gilles Depatie | 0 | +0 | 0 | - | 1 | northforgeinc.com |
| 242 | Girish Gowdra | 0 | +0 | 0 | - | 8 | intel.com |
| 243 | Girish Gowdra | 0 | +0 | 0 | - | 18 | opennetworking.org |
| 244 | Girish Gowdru | 0 | +0 | 0 | - | 6 | radisys.com |
| 245 | Girish Kumar | 0 | +0 | 0 | - | 8 | infosys.com |
| 246 | Glen Gibb | 0 | +0 | 0 | - | 1 | stanford.edu |
| 247 | Gopinath Taget | 0 | +0 | 0 | - | 10 | opennetworking.org |
| 248 | Graham Christensen | 0 | +0 | 0 | - | 1 | grahamc.com |
| 249 | Greg Troxel | 0 | +0 | 0 | - | 1 | bbn.com |
| 250 | Greg Troxel | 0 | +0 | 0 | - | 1 | bbn.com |
| 251 | Gregor Maier | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 252 | Gunaseelan | 0 | +0 | 0 | - | 1 | radisys.com |
| 253 | Gunjan Patel | 0 | +0 | 0 | - | 1 | gmail.com |
| 254 | Gustavo Silva | 0 | +0 | 0 | - | 8 | furukawalatam.com |
| 255 | Hardik Windlass | 0 | +0 | 0 | - | 18 | infosys.com |
| 256 | Hardik Windlass | 0 | +0 | 0 | - | 6 | intel.com |
| 257 | Hardik Windlass | 0 | +0 | 0 | - | 10 | opennetworking.org |
| 258 | Harsh Awasthi | 0 | +0 | 0 | - | 2 | gmail.com |
| 259 | Harsh Awasthi | 0 | +0 | 0 | - | 1 | radisys.com |
| 260 | Harshmeet Singh | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 261 | Hasso Tepper | 0 | +0 | 0 | - | 1 | gmail.com |
| 262 | Hasso Tepper | 0 | +0 | 0 | - | 1 | quagga.net |
| 263 | Hema | 0 | +0 | 0 | - | 2 | infosys.com |
| 264 | Himani Chawla | 0 | +0 | 0 | - | 8 | ciena.com |
| 265 | Himanshu Bhandari | 0 | +0 | 0 | - | 10 | infosys.com |
| 266 | Hiroshi Yokoi | 0 | +0 | 0 | - | 1 | gmail.com |
| 267 | Hitesh Chhabra | 0 | +0 | 0 | - | 1 | radisys.com |
| 268 | Holger Hildebrandt | 0 | +0 | 0 | - | 10 | adtran.com |
| 269 | Howard Persh | 0 | +0 | 0 | - | 1 | aristanetworks.com |
| 270 | Howard Persh | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 271 | Howard Persh | 0 | +0 | 0 | - | 1 | ubuntu-vm-1.(none) |
| 272 | Hu Xiuyun | 0 | +0 | 0 | - | 1 | qq.com |
| 273 | Hu xiuyun | 0 | +0 | 0 | - | 1 | hisilicon.com |
| 274 | Hung-Wei Chiu | 0 | +0 | 0 | - | 17 | opennetworking.org |
| 275 | Huseyin Ahmet AYDIN | 0 | +0 | 0 | - | 2 | netsia.com |
| 276 | Hyunsun | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 277 | Hyunsun | 0 | +0 | 0 | - | 1 | cluster.local |
| 278 | Hyunsun | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 279 | Hyunsun Moon | 0 | +0 | 0 | - | 16 | gmail.com |
| 280 | Hyunsun Moon | 0 | +0 | 0 | - | 14 | opennetworking.org |
| 281 | Hyunsun Moon | 0 | +0 | 0 | - | 2 | intel.com |
| 282 | Igor Ryzhov | 0 | +0 | 0 | - | 1 | nfware.com |
| 283 | Ilayda Ozdemir | 0 | +0 | 0 | - | 8 | netsia.com |
| 284 | Illyoung Choi | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 285 | Ingo Flaschberger | 0 | +0 | 0 | - | 1 | xip.at |
| 286 | Isaku Yamahata | 0 | +0 | 0 | - | 1 | co.jp |
| 287 | Ivan Moskalyov | 0 | +0 | 0 | - | 1 | mail.ru |
| 288 | JR Rivers | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 289 | Jacob Cooper | 0 | +0 | 0 | - | 1 | intel.com |
| 290 | Jafar Al-Gharaibeh | 0 | +0 | 0 | - | 1 | atcorp.com |
| 291 | Jaikumar Ganesh | 0 | +0 | 0 | - | 1 | google.com |
| 292 | Jakub Vrana | 0 | +0 | 0 | - | 1 | google.com |
| 293 | Jakub Zawadzki | 0 | +0 | 0 | - | 1 | darkjames.pl |
| 294 | James Li | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 295 | James W. Mills | 0 | +0 | 0 | - | 1 | gmail.com |
| 296 | Jan Klare | 0 | +0 | 0 | - | 6 | bisdn.de |
| 297 | Jan Klare | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 298 | Jarkko Pöyry | 0 | +0 | 0 | - | 1 | google.com |
| 299 | Jaroslav Fojtik | 0 | +0 | 0 | - | 1 | seznam.cz |
| 300 | Jason Huang | 0 | +0 | 0 | - | 2 | edge-core.com |
| 301 | Javier Bravo Conde | 0 | +0 | 0 | - | 1 | gslab.com |
| 302 | Jeff Bailey | 0 | +0 | 0 | - | 1 | google.com |
| 303 | Jeff Davidson | 0 | +0 | 0 | - | 1 | google.com |
| 304 | Jeff Hamilton | 0 | +0 | 0 | - | 1 | android.com |
| 305 | Jeffrey Townsend | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 306 | Jenkins | 0 | +0 | 0 | - | 15 | opencord.org |
| 307 | Jeremy Jackson | 0 | +0 | 0 | - | 1 | coplanar.net |
| 308 | Jeremy Mowery | 0 | +0 | 0 | - | 1 | arizona.edu |
| 309 | Jeremy Ronquillo | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 310 | Jesse Hall | 0 | +0 | 0 | - | 1 | google.com |
| 311 | Jian Li | 0 | +0 | 0 | - | 5 | gmail.com |
| 312 | JianHao | 0 | +0 | 0 | - | 10 | org.tw |
| 313 | JianHao | 0 | +0 | 0 | - | 2 | edge-core.com |
| 314 | Jim Carroll | 0 | +0 | 0 | - | 1 | carroll.com |
| 315 | Jim Kao | 0 | +0 | 0 | - | 1 | gmail.com |
| 316 | Jimmie Wester | 0 | +0 | 0 | - | 1 | stericsson.com |
| 317 | Jingjing Duan | 0 | +0 | 0 | - | 1 | sun.com |
| 318 | Jingzhao.Ni | 0 | +0 | 0 | - | 1 | arm.com |
| 319 | Jiri tyr | 0 | +0 | 0 | - | 1 | gmail.com |
| 320 | Joachim Nilsson | 0 | +0 | 0 | - | 1 | gmail.com |
| 321 | Joakim Tjernlund | 0 | +0 | 0 | - | 1 | transmode.se |
| 322 | Job Snijders | 0 | +0 | 0 | - | 1 | instituut.net |
| 323 | Joe Hansche | 0 | +0 | 0 | - | 1 | myyearbook.com |
| 324 | Joe Kilner | 0 | +0 | 0 | - | 1 | google.com |
| 325 | Joe Onorato | 0 | +0 | 0 | - | 1 | google.com |
| 326 | Joe Onorato | 0 | +0 | 0 | - | 1 | android.com |
| 327 | Joey Armstrong | 0 | +0 | 0 | - | 35 | opennetworking.org |
| 328 | Joey Armstrong | 0 | +0 | 0 | - | 14 | linuxfoundation.org |
| 329 | John Glotzer | 0 | +0 | 0 | - | 1 | amazon.com |
| 330 | John H. Hartman | 0 | +0 | 0 | - | 1 | akamai.com |
| 331 | John Kemp | 0 | +0 | 0 | - | 1 | uoregon.edu |
| 332 | John L. Villalovos | 0 | +0 | 0 | - | 1 | intel.com |
| 333 | John Törnblom | 0 | +0 | 0 | - | 1 | gmail.com |
| 334 | Jon Andersson | 0 | +0 | 0 | - | 1 | gmail.com |
| 335 | Jon Hall | 0 | +0 | 0 | - | 1 | ciena.com |
| 336 | Jonathan Davis | 0 | +0 | 0 | - | 1 | att.com |
| 337 | Jonathan Hart | 0 | +0 | 0 | - | 4 | gmail.com |
| 338 | Jonathan Hart | 0 | +0 | 0 | - | 36 | opennetworking.org |
| 339 | Jonathan Hart | 0 | +0 | 0 | - | 11 | onlab.us |
| 340 | Jonathan Nieder | 0 | +0 | 0 | - | 1 | google.com |
| 341 | Jonathan Stout | 0 | +0 | 0 | - | 1 | indiana.edu |
| 342 | Jonghwan Hyun | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 343 | JoonCheol Park | 0 | +0 | 0 | - | 1 | gmail.com |
| 344 | Jorge Boncompte [DTI2] | 0 | +0 | 0 | - | 1 | dti2.net |
| 345 | Jorge Gonzalez | 0 | +0 | 0 | - | 1 | google.com |
| 346 | Josh Bailey | 0 | +0 | 0 | - | 1 | google.com |
| 347 | Josh Guilfoyle | 0 | +0 | 0 | - | 1 | gmail.com |
| 348 | Josh Triplett | 0 | +0 | 0 | - | 1 | joshtriplett.org |
| 349 | Julien Campergue | 0 | +0 | 0 | - | 1 | parrot.com |
| 350 | Julius Gustavsson | 0 | +0 | 0 | - | 1 | gmail.com |
| 351 | Juliusz Chroboczek | 0 | +0 | 0 | - | 1 | jussieu.fr |
| 352 | Kailash | 0 | +0 | 0 | - | 16 | onlab.us |
| 353 | Kailash Khalasi | 0 | +0 | 0 | - | 1 | gmail.com |
| 354 | Kailash Khalasi | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 355 | Kailash Khalasi | 0 | +0 | 0 | - | 1 | kailashs-macbook-pro.local |
| 356 | Kaloyan Kovachev | 0 | +0 | 0 | - | 1 | varna.net |
| 357 | Kartikey Dubey | 0 | +0 | 0 | - | 6 | infosys.com |
| 358 | Ken Chiang | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 359 | Ken Williams | 0 | +0 | 0 | - | 1 | intel.com |
| 360 | Kengof20xx | 0 | +0 | 0 | - | 2 | furukawaelectric.com |
| 361 | Kenny Ho | 0 | +0 | 0 | - | 1 | gmail.com |
| 362 | Kent Hagerman | 0 | +0 | 0 | - | 10 | ciena.com |
| 363 | Kevin Degi | 0 | +0 | 0 | - | 1 | codeaurora.org |
| 364 | Kim Kempf | 0 | +0 | 0 | - | 1 | radisys.com |
| 365 | Kiran Poola | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 366 | Kis Gergely | 0 | +0 | 0 | - | 1 | mattakis.com |
| 367 | Klemen Sladic | 0 | +0 | 0 | - | 1 | gmail.com |
| 368 | Kris Giesing | 0 | +0 | 0 | - | 1 | google.com |
| 369 | Krishna Kolakaluri | 0 | +0 | 0 | - | 1 | deltaww.com |
| 370 | Krisztian Kovacs | 0 | +0 | 0 | - | 1 | morganstanley.com |
| 371 | Kwanhong Lee | 0 | +0 | 0 | - | 1 | windriver.com |
| 372 | Kyunam.jo | 0 | +0 | 0 | - | 1 | lge.com |
| 373 | Larry Peterson | 0 | +0 | 0 | - | 22 | onlab.us |
| 374 | Larry Peterson | 0 | +0 | 0 | - | 18 | opennetworking.org |
| 375 | Larry Peterson | 0 | +0 | 0 | - | 3 | princeton.edu |
| 376 | Leonard Herve | 0 | +0 | 0 | - | 1 | yahoo.fr |
| 377 | Leonard Herve | 0 | +0 | 0 | - | 1 | yahoo.fr |
| 378 | Leonard Tracy | 0 | +0 | 0 | - | 1 | amazon.com |
| 379 | Leonid Rosenboim | 0 | +0 | 0 | - | 1 | wrs.com |
| 380 | Leonid Rosenboim | 0 | +0 | 0 | - | 1 | windriver.com |
| 381 | Linux Foundation Administrators | 0 | +0 | 0 | - | 1 | linuxfoundation.org |
| 382 | Lou Berger | 0 | +0 | 0 | - | 1 | labn.net |
| 383 | Luca Prete | 0 | +0 | 0 | - | 46 | onlab.us |
| 384 | Luca Prete | 0 | +0 | 0 | - | 14 | opennetworking.org |
| 385 | Luca Prete | 0 | +0 | 0 | - | 3 | gmail.com |
| 386 | Luis Hector Chavez | 0 | +0 | 0 | - | 1 | google.com |
| 387 | Macauley Cheng | 0 | +0 | 0 | - | 1 | accton.com |
| 388 | Madan Jampani | 0 | +0 | 0 | - | 5 | onlab.us |
| 389 | Mandeep Singh Baines | 0 | +0 | 0 | - | 1 | google.com |
| 390 | Mani Chandel | 0 | +0 | 0 | - | 1 | tcs.com |
| 391 | Maninder | 0 | +0 | 0 | - | 7 | ciena.com |
| 392 | Manjunath Vanarajulu | 0 | +0 | 0 | - | 2 | radisys.com |
| 393 | Marc De Leenheer | 0 | +0 | 0 | - | 7 | opennetworking.org |
| 394 | Marc Herbert | 0 | +0 | 0 | - | 1 | intel.com |
| 395 | Marcelo E. Magallon | 0 | +0 | 0 | - | 1 | gmail.com |
| 396 | Marcos Aurelio Carrero | 0 | +0 | 0 | - | 7 | furukawalatam.com |
| 397 | Maria Carmela Cascino | 0 | +0 | 0 | - | 1 | reply.it |
| 398 | Marikkannu, Suresh | 0 | +0 | 0 | - | 1 | intel.com |
| 399 | Mark E. Hamilton | 0 | +0 | 0 | - | 1 | sandia.gov |
| 400 | Martin Cosyns | 0 | +0 | 0 | - | 2 | adtran.com |
| 401 | Martin Kelly | 0 | +0 | 0 | - | 1 | xevo.com |
| 402 | Martin Winter | 0 | +0 | 0 | - | 1 | opensourcerouting.org |
| 403 | Masaya Suzuki | 0 | +0 | 0 | - | 1 | google.com |
| 404 | Matevz Langus | 0 | +0 | 0 | - | 1 | borea.si |
| 405 | Mathias Krause | 0 | +0 | 0 | - | 1 | secunet.com |
| 406 | Mathieu Goessens | 0 | +0 | 0 | - | 1 | poolp.org |
| 407 | Mats Bengtsson | 0 | +0 | 0 | - | 1 | gmail.com |
| 408 | Matt Gumbel | 0 | +0 | 0 | - | 1 | intel.com |
| 409 | Matt Jeanneret | 0 | +0 | 0 | - | 9 | att.com |
| 410 | Matteo | 0 | +0 | 0 | - | 2 | github.com |
| 411 | Matteo Scandolo | 0 | +0 | 0 | - | 124 | gmail.com |
| 412 | Matteo Scandolo | 0 | +0 | 0 | - | 72 | opennetworking.org |
| 413 | Matteo Scandolo | 0 | +0 | 0 | - | 10 | intel.com |
| 414 | Matteo Scandolo | 0 | +0 | 0 | - | 1 | ted-intel.local |
| 415 | Matteo Scandolo | 0 | +0 | 0 | - | 7 | onlab.us |
| 416 | Matteo Scandolo | 0 | +0 | 0 | - | 3 | gmail.com |
| 417 | Matteo Scandolo | 0 | +0 | 0 | - | 1 | ted.local |
| 418 | Matteo Scandolo | 0 | +0 | 0 | - | 1 | ted-4.local |
| 419 | Matteo Scandolo | 0 | +0 | 0 | - | 1 | link-me.it |
| 420 | Matthew Buckett | 0 | +0 | 0 | - | 1 | ac.uk |
| 421 | Matthew Davis | 0 | +0 | 0 | - | 1 | telstra.com |
| 422 | Matthias Ferdinand | 0 | +0 | 0 | - | 1 | 14v.de |
| 423 | Matthieu Boutier | 0 | +0 | 0 | - | 1 | univ-paris-diderot.fr |
| 424 | Matthieu Boutier | 0 | +0 | 0 | - | 1 | jussieu.fr |
| 425 | Matti-Oskari Leppänen | 0 | +0 | 0 | - | 1 | gmail.com |
| 426 | Max Chu | 0 | +0 | 0 | - | 11 | gmail.com |
| 427 | Max Chu | 0 | +0 | 0 | - | 3 | onlab.us |
| 428 | Max Klyus | 0 | +0 | 0 | - | 1 | gmail.com |
| 429 | Max Liu | 0 | +0 | 0 | - | 1 | gmail.com |
| 430 | Michael Best | 0 | +0 | 0 | - | 1 | nokia.com |
| 431 | Michael Lambert | 0 | +0 | 0 | - | 1 | psc.edu |
| 432 | Michael Rossberg | 0 | +0 | 0 | - | 1 | tu-ilmenau.de |
| 433 | Michael Zingg | 0 | +0 | 0 | - | 1 | zhaw.ch |
| 434 | Michal Sekletar | 0 | +0 | 0 | - | 1 | redhat.com |
| 435 | Mickaël Salaün | 0 | +0 | 0 | - | 1 | digikod.net |
| 436 | Mike Bjorge | 0 | +0 | 0 | - | 1 | google.com |
| 437 | Mike Frysinger | 0 | +0 | 0 | - | 1 | google.com |
| 438 | Mike Lockwood | 0 | +0 | 0 | - | 1 | android.com |
| 439 | Mike Pontillo | 0 | +0 | 0 | - | 1 | gmail.com |
| 440 | Milan Kocian | 0 | +0 | 0 | - | 1 | wq.cz |
| 441 | Mitchel Humpherys | 0 | +0 | 0 | - | 1 | codeaurora.org |
| 442 | Morgan Stewart | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 443 | Moshe Levi | 0 | +0 | 0 | - | 2 | mellanox.com |
| 444 | Murat Parlakisik | 0 | +0 | 0 | - | 5 | parlakisik.com |
| 445 | Naga Manjunath | 0 | +0 | 0 | - | 4 | radisys.com |
| 446 | Naresh Kumar Palanisamy | 0 | +0 | 0 | - | 1 | radisys.com |
| 447 | Naseer Ahmed | 0 | +0 | 0 | - | 1 | gmail.com |
| 448 | Nasser Grainawi | 0 | +0 | 0 | - | 1 | codeaurora.org |
| 449 | Naveen Sampath | 0 | +0 | 0 | - | 1 | radisys.com |
| 450 | Neha Sharma | 0 | +0 | 0 | - | 6 | infosys.com |
| 451 | Nick Hilliard | 0 | +0 | 0 | - | 1 | foobar.org |
| 452 | Nick Hilliard | 0 | +0 | 0 | - | 1 | inex.ie |
| 453 | Nico Golde | 0 | +0 | 0 | - | 1 | debian.org |
| 454 | Nico Sallembien | 0 | +0 | 0 | - | 1 | google.com |
| 455 | Nicolas Cornu | 0 | +0 | 0 | - | 1 | yahoo.fr |
| 456 | Nicolas Dichtel | 0 | +0 | 0 | - | 1 | 6wind.com |
| 457 | Nicolas Palpacuer | 0 | +0 | 0 | - | 2 | att.com |
| 458 | Nikolai Merinov | 0 | +0 | 0 | - | 1 | inango-systems.com |
| 459 | Nitin Subramanian | 0 | +0 | 0 | - | 1 | zooglr.com |
| 460 | Nolan Leake | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 461 | Oleg A. Arkhangelsky | 0 | +0 | 0 | - | 1 | yandex.ru |
| 462 | Oleg Polyakov | 0 | +0 | 0 | - | 1 | northforgeinc.com |
| 463 | Olivier Cochard-Labbé | 0 | +0 | 0 | - | 1 | cochard.me |
| 464 | Olivier Dugeon | 0 | +0 | 0 | - | 1 | orange.com |
| 465 | Olof Johansson | 0 | +0 | 0 | - | 1 | sonymobile.com |
| 466 | Omar Abdelkader | 0 | +0 | 0 | - | 1 | gmail.com |
| 467 | Ondrej Zajicek | 0 | +0 | 0 | - | 1 | crfreenet.org |
| 468 | Onur Kalinagac | 0 | +0 | 0 | - | 2 | netsia.com |
| 469 | Orhan Kupusoglu | 0 | +0 | 0 | - | 3 | netsia.com |
| 470 | Osman Amjad | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 471 | PUSHP RAJ | 0 | +0 | 0 | - | 1 | gslab.com |
| 472 | Pascal Bach | 0 | +0 | 0 | - | 1 | siemens.com |
| 473 | Pascal Muetschard | 0 | +0 | 0 | - | 1 | google.com |
| 474 | Patrick Dubroy | 0 | +0 | 0 | - | 1 | google.com |
| 475 | Paul Jakma | 0 | +0 | 0 | - | 1 | jakma.org |
| 476 | Paul Jakma | 0 | +0 | 0 | - | 1 | hpe.com |
| 477 | Paul Jakma | 0 | +0 | 0 | - | 1 | opensourcerouting.org |
| 478 | Paul Jakma | 0 | +0 | 0 | - | 1 | quagga.net |
| 479 | Paul Jakma | 0 | +0 | 0 | - | 1 | sun.com |
| 480 | Paul P Komkoff Jr | 0 | +0 | 0 | - | 1 | stingr.net |
| 481 | Pawel Wieczorkiewicz | 0 | +0 | 0 | - | 1 | suse.de |
| 482 | Pawit Pornkitprasan | 0 | +0 | 0 | - | 1 | gmail.com |
| 483 | Peter K. Lee | 0 | +0 | 0 | - | 1 | intercloud.net |
| 484 | Peter Lee | 0 | +0 | 0 | - | 1 | corenova.com |
| 485 | Peter Pentchev | 0 | +0 | 0 | - | 1 | ringlet.net |
| 486 | Peter Szilagyi | 0 | +0 | 0 | - | 1 | gmail.com |
| 487 | Phaneendra Manda | 0 | +0 | 0 | - | 1 | radisys.com |
| 488 | Phil Laverdiere | 0 | +0 | 0 | - | 1 | securecomputing.com |
| 489 | Philippe Guibert | 0 | +0 | 0 | - | 1 | 6wind.com |
| 490 | Pier | 0 | +0 | 0 | - | 2 | onlab.us |
| 491 | Pierre Tardy | 0 | +0 | 0 | - | 1 | intel.com |
| 492 | Pingping Lin | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 493 | Pingping Lin | 0 | +0 | 0 | - | 25 | onlab.us |
| 494 | Piotr Chytła | 0 | +0 | 0 | - | 1 | packetconsulting.pl |
| 495 | Pradosh Mohapatra | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 496 | Pragya Arya | 0 | +0 | 0 | - | 2 | radisys.com |
| 497 | Prateek Sarda | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 498 | Prince Pereira | 0 | +0 | 0 | - | 1 | radisys.com |
| 499 | Pär Åsfält | 0 | +0 | 0 | - | 1 | gmail.com |
| 500 | Qianqian Hu | 0 | +0 | 0 | - | 1 | com.cn |
| 501 | Quentin Young | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 502 | Rajeswara Rao | 0 | +0 | 0 | - | 1 | radisys.com |
| 503 | Rakesh Garimella | 0 | +0 | 0 | - | 1 | sophos.com |
| 504 | Randy Levensalor | 0 | +0 | 0 | - | 1 | cablelabs.com |
| 505 | Raphael Vicente Rosa | 0 | +0 | 0 | - | 5 | opennetworking.org |
| 506 | Ray Milkey | 0 | +0 | 0 | - | 5 | onlab.us |
| 507 | Ray Milkey | 0 | +0 | 0 | - | 2 | gmail.com |
| 508 | Ray Milkey | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 509 | Remi Gacogne | 0 | +0 | 0 | - | 1 | coredump.fr |
| 510 | Renato Westphal | 0 | +0 | 0 | - | 1 | opensourcerouting.org |
| 511 | Renato Westphal | 0 | +0 | 0 | - | 1 | gmail.com |
| 512 | Renaud Paquay | 0 | +0 | 0 | - | 1 | google.com |
| 513 | Rich Lane | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 514 | Rich Lane | 0 | +0 | 0 | - | 1 | gmail.com |
| 515 | Rich Lane | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 516 | Richard Jankowski | 0 | +0 | 0 | - | 1 | ciena.com |
| 517 | Rizwan Haider | 0 | +0 | 0 | - | 4 | nokia.com |
| 518 | Rob Sherwood | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 519 | Rob Ward | 0 | +0 | 0 | - | 1 | googlemail.com |
| 520 | Robert Bays | 0 | +0 | 0 | - | 1 | vyatta.com |
| 521 | Roderick Schertler | 0 | +0 | 0 | - | 1 | argon.org |
| 522 | Roger Luethi | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 523 | Rohan Agrawal | 0 | +0 | 0 | - | 7 | infosys.com |
| 524 | Roman Bubyr | 0 | +0 | 0 | - | 1 | gmail.com |
| 525 | Roman Hoog Antink | 0 | +0 | 0 | - | 1 | open.ch |
| 526 | Roy | 0 | +0 | 0 | - | 1 | vio.us |
| 527 | Roy Lee | 0 | +0 | 0 | - | 1 | gmail.com |
| 528 | Ruchit Bawa | 0 | +0 | 0 | - | 1 | gslab.com |
| 529 | Ruslan Bilovol | 0 | +0 | 0 | - | 1 | gmail.com |
| 530 | Rusty Eddy | 0 | +0 | 0 | - | 1 | rustyeddy.com |
| 531 | Ryan | 0 | +0 | 0 | - | 1 | com.tw |
| 532 | S.Çağlar Onur | 0 | +0 | 0 | - | 1 | 10ur.org |
| 533 | Saleil Bhat | 0 | +0 | 0 | - | 5 | stanford.edu |
| 534 | Samuel Holland | 0 | +0 | 0 | - | 1 | sholland.org |
| 535 | Santosh Kumar | 0 | +0 | 0 | - | 1 | altencalsoftlabs.com |
| 536 | Sapan Bhatia | 0 | +0 | 0 | - | 43 | gmail.com |
| 537 | Sapan Bhatia | 0 | +0 | 0 | - | 15 | opennetworking.org |
| 538 | Sapan Bhatia | 0 | +0 | 0 | - | 1 | princeton.org |
| 539 | Sapan Bhatia | 0 | +0 | 0 | - | 1 | sapans-macbook-pro.local |
| 540 | Sapan Bhatia | 0 | +0 | 0 | - | 1 | onlab.us |
| 541 | Sapan Bhatia | 0 | +0 | 0 | - | 1 | princeton.edu |
| 542 | Sarah Owens | 0 | +0 | 0 | - | 1 | inkylabs.com |
| 543 | Saurav Das | 0 | +0 | 0 | - | 8 | stanford.edu |
| 544 | Saurav Das | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 545 | Savannah SR#108542 | 0 | +0 | 0 | - | 1 | atcorp.com |
| 546 | Scott Anderson | 0 | +0 | 0 | - | 1 | droidmod.org |
| 547 | Scott Baker | 0 | +0 | 0 | - | 75 | gmail.com |
| 548 | Scott Baker | 0 | +0 | 0 | - | 3 | opennetworking.org |
| 549 | Scott Baker | 0 | +0 | 0 | - | 14 | onlab.us |
| 550 | Scott Baker | 0 | +0 | 0 | - | 1 | intel.com |
| 551 | Scott Fan | 0 | +0 | 0 | - | 1 | gmail.com |
| 552 | Sean Condon | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 553 | SeanCondon | 0 | +0 | 0 | - | 1 | intel.com |
| 554 | Sebastian Frias | 0 | +0 | 0 | - | 1 | gmail.com |
| 555 | Sebastian Schmidt | 0 | +0 | 0 | - | 1 | yath.de |
| 556 | Sebastian Schuberth | 0 | +0 | 0 | - | 1 | gmail.com |
| 557 | Sergey Y. Afonin | 0 | +0 | 0 | - | 1 | altlinux.ru |
| 558 | Serj Kalichev | 0 | +0 | 0 | - | 1 | gmail.com |
| 559 | Shad Ansari | 0 | +0 | 0 | - | 12 | opennetworking.org |
| 560 | Shad Ansari | 0 | +0 | 0 | - | 1 | onlab.us |
| 561 | Shad Ansari | 0 | +0 | 0 | - | 1 | attlocal.net |
| 562 | Shad Ansari | 0 | +0 | 0 | - | 2 | intel.com |
| 563 | Shad Ansari | 0 | +0 | 0 | - | 1 | gmail.com |
| 564 | Shad Ansari | 0 | +0 | 0 | - | 1 | opennetworking.org” |
| 565 | Shad Ansari | 0 | +0 | 0 | - | 1 | carbon.local |
| 566 | Shawn Pearce | 0 | +0 | 0 | - | 1 | google.com |
| 567 | Shivanagouda Malaginahalli | 0 | +0 | 0 | - | 2 | radisys.com |
| 568 | Sho SHIMIZU | 0 | +0 | 0 | - | 1 | fujitsu.com |
| 569 | Shouheng Zhang | 0 | +0 | 0 | - | 1 | intel.com |
| 570 | Shrey Baid | 0 | +0 | 0 | - | 4 | gmail.com |
| 571 | ShreyaPandita | 0 | +0 | 0 | - | 1 | iu.edu |
| 572 | Shubham Sharma | 0 | +0 | 0 | - | 5 | infosys.com |
| 573 | Shudong Zhou | 0 | +0 | 0 | - | 1 | gmail.com |
| 574 | Simon Hunt | 0 | +0 | 0 | - | 3 | onlab.us |
| 575 | Simon Ruggier | 0 | +0 | 0 | - | 1 | gmail.com |
| 576 | Simran Basi | 0 | +0 | 0 | - | 1 | google.com |
| 577 | Siobhan Tully | 0 | +0 | 0 | - | 1 | verivue.com |
| 578 | Skyler Kaufman | 0 | +0 | 0 | - | 1 | google.com |
| 579 | Sonal Kasliwal | 0 | +0 | 0 | - | 3 | infosys.com |
| 580 | Sreeju Sreedhar | 0 | +0 | 0 | - | 3 | jabil.com |
| 581 | Srikanth Vavilapalli | 0 | +0 | 0 | - | 10 | ericsson.com |
| 582 | Stas Nichiporovich | 0 | +0 | 0 | - | 1 | iptel.by |
| 583 | Stefan Beller | 0 | +0 | 0 | - | 1 | google.com |
| 584 | Stephen Finucane | 0 | +0 | 0 | - | 1 | hotmail.com |
| 585 | Stephen Hemminger | 0 | +0 | 0 | - | 1 | networkplumber.org |
| 586 | Stephen Hemminger | 0 | +0 | 0 | - | 1 | vyatta.com |
| 587 | Stephen Hemminger | 0 | +0 | 0 | - | 1 | vyatta.com |
| 588 | Stephen Hemminger | 0 | +0 | 0 | - | 1 | debian.(none) |
| 589 | Steve Hill | 0 | +0 | 0 | - | 1 | sackheads.org |
| 590 | Steve Pucci | 0 | +0 | 0 | - | 1 | google.com |
| 591 | Steve Rae | 0 | +0 | 0 | - | 1 | raedomain.com |
| 592 | Steven Burrows | 0 | +0 | 0 | - | 1 | villa-technologies.com |
| 593 | Stig Thormodsrud | 0 | +0 | 0 | - | 1 | vyatta.com |
| 594 | Subbaiah Venkata | 0 | +0 | 0 | - | 1 | google.com |
| 595 | Suchitra Vemuri | 0 | +0 | 0 | - | 8 | onlab.us |
| 596 | Suchitra Vemuri | 0 | +0 | 0 | - | 4 | opennetworking.org |
| 597 | Suhas Gururaj | 0 | +0 | 0 | - | 1 | radisys.com |
| 598 | Suraj Gour | 0 | +0 | 0 | - | 1 | infosys.com |
| 599 | Svata Dedic | 0 | +0 | 0 | - | 1 | klfree.net |
| 600 | Sébastien Luttringer | 0 | +0 | 0 | - | 1 | seblu.net |
| 601 | T.R. Fullhart | 0 | +0 | 0 | - | 1 | google.com |
| 602 | Takahiro Suzuki | 0 | +0 | 0 | - | 5 | opennetworking.org |
| 603 | Takashi Sogabe | 0 | +0 | 0 | - | 1 | ad.jp |
| 604 | Takeshi Kanemoto | 0 | +0 | 0 | - | 1 | sonymobile.com |
| 605 | Tatsuya Yabe | 0 | +0 | 0 | - | 1 | stanford.edu |
| 606 | Terence Haddock | 0 | +0 | 0 | - | 1 | google.com |
| 607 | Test User | 0 | +0 | 0 | - | 2 | null.com |
| 608 | Than McIntosh | 0 | +0 | 0 | - | 1 | google.com |
| 609 | Thangavelu K S | 0 | +0 | 0 | - | 1 | ciena.com |
| 610 | The Android Open Source Project | 0 | +0 | 0 | - | 1 | android.com |
| 611 | Thiago Farina | 0 | +0 | 0 | - | 1 | gmail.com |
| 612 | Thijs Kinkhorst | 0 | +0 | 0 | - | 1 | debian.org |
| 613 | Thiyagarajan Subramani | 0 | +0 | 0 | - | 3 | radisys.com |
| 614 | Thomas Lee S | 0 | +0 | 0 | - | 5 | radisys.com |
| 615 | Thomas Petazzoni | 0 | +0 | 0 | - | 1 | free-electrons.com |
| 616 | Thomas Ries | 0 | +0 | 0 | - | 1 | gmx.net |
| 617 | Thomas Vachuska | 0 | +0 | 0 | - | 6 | onlab.us |
| 618 | Thorvald Natvig | 0 | +0 | 0 | - | 1 | medallia.com |
| 619 | Tim Kilbourn | 0 | +0 | 0 | - | 1 | google.com |
| 620 | Tim Schumacher | 0 | +0 | 0 | - | 1 | arcor.de |
| 621 | Timo Lotterbach | 0 | +0 | 0 | - | 1 | bmw-carit.de |
| 622 | Timo Schöler | 0 | +0 | 0 | - | 1 | kroenchenstadt.de |
| 623 | Timo Teräs | 0 | +0 | 0 | - | 1 | iki.fi |
| 624 | Tinoj Joseph | 0 | +0 | 0 | - | 3 | radisys.com |
| 625 | Tiruveedula, Vijaya | 0 | +0 | 0 | - | 2 | intel.com |
| 626 | Tobias Droste | 0 | +0 | 0 | - | 1 | gmx.de |
| 627 | Tom Goff | 0 | +0 | 0 | - | 1 | boeing.com |
| 628 | Tom Henderson | 0 | +0 | 0 | - | 1 | tomh.org |
| 629 | Tomasz Pala | 0 | +0 | 0 | - | 1 | pld-linux.org |
| 630 | Tony Chou | 0 | +0 | 0 | - | 1 | gmail.com |
| 631 | Tony Mack | 0 | +0 | 0 | - | 2 | gmail.com |
| 632 | Tony Mack | 0 | +0 | 0 | - | 1 | princeton.edu |
| 633 | Tony Mack | 0 | +0 | 0 | - | 1 | princeton.edu |
| 634 | Tony Mack | 0 | +0 | 0 | - | 1 | princeton.edu |
| 635 | Tony van der Peet | 0 | +0 | 0 | - | 1 | co.nz |
| 636 | Torne (Richard Coles) | 0 | +0 | 0 | - | 1 | google.com |
| 637 | Torsten Thieme | 0 | +0 | 0 | - | 5 | adtran.com |
| 638 | Trond Norbye | 0 | +0 | 0 | - | 1 | gmail.com |
| 639 | Tseng, Yi | 0 | +0 | 0 | - | 1 | intel.com |
| 640 | Tunahan Sezen | 0 | +0 | 0 | - | 3 | netsia.com |
| 641 | Ubuntu | 0 | +0 | 0 | - | 1 | voltha |
| 642 | Udaya Shankara KS | 0 | +0 | 0 | - | 1 | gmail.com |
| 643 | Ulrich Weber | 0 | +0 | 0 | - | 1 | sophos.com |
| 644 | Ulrik Sjolin | 0 | +0 | 0 | - | 1 | gmail.com |
| 645 | Ulrik Sjölin | 0 | +0 | 0 | - | 1 | sonyericsson.com |
| 646 | User | 0 | +0 | 0 | - | 1 | hackershells.com |
| 647 | Vadim Bendebury | 0 | +0 | 0 | - | 1 | chromium.org |
| 648 | Varun Belur | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 649 | Vasilis Tsiligiannis | 0 | +0 | 0 | - | 1 | silverton.gr |
| 650 | Victor Boivie | 0 | +0 | 0 | - | 1 | sonymobile.com |
| 651 | Victor Boivie | 0 | +0 | 0 | - | 1 | sonyericsson.com |
| 652 | Vijaya Rani | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 653 | Vijaya Tiruveedula | 0 | +0 | 0 | - | 1 | compute.internal |
| 654 | Vijaya Tiruveedula | 0 | +0 | 0 | - | 1 | localhost |
| 655 | Vijaykumar Kushwaha | 0 | +0 | 0 | - | 2 | infosys.com |
| 656 | Vincent Bernat | 0 | +0 | 0 | - | 1 | luffy.cx |
| 657 | Vincent JARDIN | 0 | +0 | 0 | - | 1 | 6wind.com |
| 658 | Vini Gajjar | 0 | +0 | 0 | - | 2 | gslab.com |
| 659 | Vipin Kumar | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 660 | Vishal Kumar | 0 | +0 | 0 | - | 1 | gmail.com |
| 661 | Vitaliy Senchyshyn | 0 | +0 | 0 | - | 1 | toroki.com |
| 662 | Vivek Venkatraman | 0 | +0 | 0 | - | 1 | cumulusnetworks.com |
| 663 | Vladimir L Ivanov | 0 | +0 | 0 | - | 1 | yandex-team.ru |
| 664 | Vyacheslav Trushkin | 0 | +0 | 0 | - | 1 | dogonthesun.net |
| 665 | Vystoropskyi, Sergii | 0 | +0 | 0 | - | 1 | amazon.com |
| 666 | Wailok Shum | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 667 | Warren Turkal | 0 | +0 | 0 | - | 1 | ooyala.com |
| 668 | Wataru Tanitsu | 0 | +0 | 0 | - | 1 | ate-mahoroba.jp |
| 669 | Wei-Yu Chen | 0 | +0 | 0 | - | 18 | opennetworking.org |
| 670 | Wei-Yu Chen | 0 | +0 | 0 | - | 12 | gmail.com |
| 671 | Wei-Yu Chen | 0 | +0 | 0 | - | 1 | intel.com |
| 672 | Wenjian Ma | 0 | +0 | 0 | - | 1 | 163.com |
| 673 | Will Richey | 0 | +0 | 0 | - | 1 | gmail.com |
| 674 | William Kurkian | 0 | +0 | 0 | - | 5 | gmail.com |
| 675 | William Kurkian | 0 | +0 | 0 | - | 5 | cisco.com |
| 676 | Wilson Ng | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 677 | Wink Saville | 0 | +0 | 0 | - | 1 | saville.com |
| 678 | Wink Saville | 0 | +0 | 0 | - | 1 | google.com |
| 679 | Woojoong Kim | 0 | +0 | 0 | - | 20 | opennetworking.org |
| 680 | Xiaodong Xu | 0 | +0 | 0 | - | 1 | gmail.com |
| 681 | Xiaohui Chen | 0 | +0 | 0 | - | 1 | google.com |
| 682 | Xin Li | 0 | +0 | 0 | - | 1 | google.com |
| 683 | YAMAMOTO Shigeru | 0 | +0 | 0 | - | 1 | ad.jp |
| 684 | YJ | 0 | +0 | 0 | - | 1 | furukawalatam.com |
| 685 | YOUNG HO CHA | 0 | +0 | 0 | - | 1 | gmail.com |
| 686 | Yang Zhenhui | 0 | +0 | 0 | - | 1 | sonymobile.com |
| 687 | Yann Droneaud | 0 | +0 | 0 | - | 1 | opteya.com |
| 688 | Yasuhiro Ohara | 0 | +0 | 0 | - | 1 | ac.jp |
| 689 | Yestin Sun | 0 | +0 | 0 | - | 1 | gmail.com |
| 690 | Yi Tseng | 0 | +0 | 0 | - | 6 | opennetworking.org |
| 691 | Yi Tseng | 0 | +0 | 0 | - | 2 | gmail.com |
| 692 | You Wang | 0 | +0 | 0 | - | 9 | opennetworking.org |
| 693 | You Wang | 0 | +0 | 0 | - | 1 | opennetworkingorg |
| 694 | You Wang | 0 | +0 | 0 | - | 1 | onlab.us |
| 695 | Yunpeng Zhang | 0 | +0 | 0 | - | 2 | gmail.com |
| 696 | Yuta HIGUCHI | 0 | +0 | 0 | - | 3 | nec.com |
| 697 | Zac Livingston | 0 | +0 | 0 | - | 1 | codeaurora.org |
| 698 | Zack Williams | 0 | +0 | 0 | - | 182 | opennetworking.org |
| 699 | Zack Williams | 0 | +0 | 0 | - | 9 | intel.com |
| 700 | Zack Williams | 0 | +0 | 0 | - | 12 | artisancomputer.com |
| 701 | Zack Williams | 0 | +0 | 0 | - | 28 | arizona.edu |
| 702 | Zack Williams | 0 | +0 | 0 | - | 3 | github.com |
| 703 | Zafer Kaban | 0 | +0 | 0 | - | 1 | netsia.com |
| 704 | Zdravko Bozakov | 0 | +0 | 0 | - | 1 | radisys.com |
| 705 | Zhiguang Li | 0 | +0 | 0 | - | 1 | gmail.com |
| 706 | Zsolt Haraszti | 0 | +0 | 0 | - | 5 | ciena.com |
| 707 | abat | 0 | +0 | 0 | - | 1 | bigswitch.com |
| 708 | adtran | 0 | +0 | 0 | - | 1 | adtran.com |
| 709 | agmimidi | 0 | +0 | 0 | - | 2 | dtu.dk |
| 710 | aishwaryarana01 | 0 | +0 | 0 | - | 2 | gmail.com |
| 711 | aishwaryarana01 | 0 | +0 | 0 | - | 1 | att.com |
| 712 | alshabib | 0 | +0 | 0 | - | 31 | gmail.com |
| 713 | anatoly techtonik | 0 | +0 | 0 | - | 1 | gmail.com |
| 714 | ashokrad | 0 | +0 | 0 | - | 1 | hcl.com |
| 715 | badhri85 | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 716 | badhri85 | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 717 | badhri85 | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 718 | badhri85 | 0 | +0 | 0 | - | 1 | cluster.local |
| 719 | bharat raj | 0 | +0 | 0 | - | 1 | radisys.com |
| 720 | bijia | 0 | +0 | 0 | - | 1 | xiaomi.com |
| 721 | boris yakubov | 0 | +0 | 0 | - | 1 | ruggedcom.com |
| 722 | boyoung | 0 | +0 | 0 | - | 2 | gmail.com |
| 723 | breezestars | 0 | +0 | 0 | - | 3 | gmail.com |
| 724 | caowei | 0 | +0 | 0 | - | 1 | gmail.com |
| 725 | castroflavio | 0 | +0 | 0 | - | 1 | gatech.edu |
| 726 | cbabu | 0 | +0 | 0 | - | 2 | radisys.com |
| 727 | chenguodong | 0 | +0 | 0 | - | 1 | huawei.com |
| 728 | chiisaihayashi | 0 | +0 | 0 | - | 1 | gmail.com |
| 729 | chip_boling | 0 | +0 | 0 | - | 2 | gmail.com |
| 730 | chrli | 0 | +0 | 0 | - | 1 | google.com |
| 731 | cuilin2018 | 0 | +0 | 0 | - | 2 | cigtech.com |
| 732 | dileepbk | 0 | +0 | 0 | - | 2 | edge-core.com |
| 733 | divyadesai | 0 | +0 | 0 | - | 12 | infosys.com |
| 734 | dmohapatro | 0 | +0 | 0 | - | 1 | ltts.com |
| 735 | dpaul | 0 | +0 | 0 | - | 4 | radisys.com |
| 736 | dvaddire | 0 | +0 | 0 | - | 5 | ciena.com |
| 737 | ederlf | 0 | +0 | 0 | - | 1 | com.br |
| 738 | fran | 0 | +0 | 0 | - | 1 | gmail.com |
| 739 | francesco | 0 | +0 | 0 | - | 1 | onlab.us |
| 740 | gerardo.laurenzi | 0 | +0 | 0 | - | 4 | hcl.com |
| 741 | gongysh | 0 | +0 | 0 | - | 1 | 99cloud.net |
| 742 | gunjan5 | 0 | +0 | 0 | - | 1 | ciena.com |
| 743 | gwsapan | 0 | +0 | 0 | - | 1 | princeton.edu |
| 744 | heasley | 0 | +0 | 0 | - | 1 | shrubbery.net |
| 745 | heping | 0 | +0 | 0 | - | 1 | hotmail.com |
| 746 | hkouser | 0 | +0 | 0 | - | 4 | radisys.com |
| 747 | jcnelson | 0 | +0 | 0 | - | 1 | princeton.edu |
| 748 | jeremy | 0 | +0 | 0 | - | 1 | emulab.net |
| 749 | ke han | 0 | +0 | 0 | - | 4 | com.cn |
| 750 | kesavand | 0 | +0 | 0 | - | 9 | gmail.com |
| 751 | kevinb | 0 | +0 | 0 | - | 1 | com.tw |
| 752 | khenaidoo | 0 | +0 | 0 | - | 9 | ciena.com |
| 753 | kishore | 0 | +0 | 0 | - | 4 | radisys.com |
| 754 | kitty | 0 | +0 | 0 | - | 1 | hpe.com |
| 755 | kmarquardsen | 0 | +0 | 0 | - | 1 | opennetworking.org |
| 756 | macauley | 0 | +0 | 0 | - | 1 | gmail.com |
| 757 | macauley | 0 | +0 | 0 | - | 1 | google.com |
| 758 | manikkaraj k | 0 | +0 | 0 | - | 3 | radisys.com |
| 759 | mc | 0 | +0 | 0 | - | 3 | edge-core.com |
| 760 | mcord | 0 | +0 | 0 | - | 1 | mcords-macbook-pro.local |
| 761 | michele.pezzutti | 0 | +0 | 0 | - | 1 | hcl.com |
| 762 | mpagenko | 0 | +0 | 0 | - | 2 | adtran.com |
| 763 | nickhuang | 0 | +0 | 0 | - | 1 | edge-core.com |
| 764 | nikesh.krishnan | 0 | +0 | 0 | - | 7 | radisys.com |
| 765 | nosignal | 0 | +0 | 0 | - | 2 | edu.tw |
| 766 | npujar | 0 | +0 | 0 | - | 4 | radisys.com |
| 767 | onf | 0 | +0 | 0 | - | 1 | onfs-macbook-pro-2.local |
| 768 | onkar.kundargi | 0 | +0 | 0 | - | 1 | sterlite.com |
| 769 | onkarkundargi | 0 | +0 | 0 | - | 2 | gmail.com |
| 770 | ozgecanetsia | 0 | +0 | 0 | - | 2 | netsia.com |
| 771 | pelya | 0 | +0 | 0 | - | 1 | gmail.com |
| 772 | ph4r05 | 0 | +0 | 0 | - | 1 | gmail.com |
| 773 | pierventre | 0 | +0 | 0 | - | 7 | opennetworking.org |
| 774 | pudelkoM | 0 | +0 | 0 | - | 1 | github.com |
| 775 | rajesh | 0 | +0 | 0 | - | 1 | radisys.com |
| 776 | rdudyala | 0 | +0 | 0 | - | 2 | tcs.com |
| 777 | root | 0 | +0 | 0 | - | 1 | ubuntu-vm-1.(none) |
| 778 | root | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 779 | root | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 780 | root | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 781 | root | 0 | +0 | 0 | - | 1 | emulab.net |
| 782 | root | 0 | +0 | 0 | - | 1 | localhost.localdomain |
| 783 | root | 0 | +0 | 0 | - | 1 | vicci.org |
| 784 | saikrishna edupuganti | 0 | +0 | 0 | - | 2 | intel.com |
| 785 | salmansiddiqui | 0 | +0 | 0 | - | 8 | gmail.com |
| 786 | sangho | 0 | +0 | 0 | - | 1 | onlab.us |
| 787 | sbarbari | 0 | +0 | 0 | - | 3 | ciena.com |
| 788 | sbconsulting | 0 | +0 | 0 | - | 1 | github.com |
| 789 | schowdhury | 0 | +0 | 0 | - | 1 | radisys.com |
| 790 | selvamuthukumaran_c | 0 | +0 | 0 | - | 3 | infosys.com |
| 791 | sepon | 0 | +0 | 0 | - | 4 | com.tr |
| 792 | shad | 0 | +0 | 0 | - | 1 | prod1.menlo |
| 793 | shivani vaidya | 0 | +0 | 0 | - | 1 | onlab.us |
| 794 | siddharthgogar | 0 | +0 | 0 | - | 2 | gmail.com |
| 795 | slowr | 0 | +0 | 0 | - | 2 | opennetworking.org |
| 796 | slowr | 0 | +0 | 0 | - | 1 | forth.gr |
| 797 | slowr | 0 | +0 | 0 | - | 1 | uoc.gr |
| 798 | smbaker | 0 | +0 | 0 | - | 1 | localhost.localdomain |
| 799 | smbaker | 0 | +0 | 0 | - | 1 | fc8-storktest.lan |
| 800 | srikanthvavila | 0 | +0 | 0 | - | 1 | github.com |
| 801 | sslobodr | 0 | +0 | 0 | - | 1 | ciena.com |
| 802 | stevenchiu30801 | 0 | +0 | 0 | - | 1 | gmail.com |
| 803 | suhasgrao | 0 | +0 | 0 | - | 1 | gmail.com |
| 804 | sumithdev09 | 0 | +0 | 0 | - | 1 | gmail.com |
| 805 | svavilap | 0 | +0 | 0 | - | 1 | cloudlab.us |
| 806 | svavilap | 0 | +0 | 0 | - | 1 | emulab.net |
| 807 | teone | 0 | +0 | 0 | - | 1 | onlab.us |
| 808 | teone | 0 | +0 | 0 | - | 1 | emulab.net |
| 809 | tmack-pl | 0 | +0 | 0 | - | 1 | princeton.edu |
| 810 | trevor tao | 0 | +0 | 0 | - | 1 | arm.com |
| 811 | ubuntu | 0 | +0 | 0 | - | 1 | cord.lab |
| 812 | ubuntu | 0 | +0 | 0 | - | 1 | cluster.local |
| 813 | uwe ottrembka | 0 | +0 | 0 | - | 2 | adtran.com |
| 814 | vigneshethiraj | 0 | +0 | 0 | - | 9 | infosys.com |
| 815 | vikschw | 0 | +0 | 0 | - | 1 | gmail.com |
| 816 | vinod | 0 | +0 | 0 | - | 3 | radisys.com |
| 817 | yasin sapli | 0 | +0 | 0 | - | 7 | netsia.com |
| 818 | zhubingbing | 0 | +0 | 0 | - | 1 | gmail.com |
| 819 | Łukasz Gardoń | 0 | +0 | 0 | - | 1 | gmail.com |
| 820 | 高鹏 | 0 | +0 | 0 | - | 1 | gmail.com |

## 📊 Gerrit Projects

| Gerrit Project | Commits | LOC | Contributors | Days Inactive | Last Commit Date | Status |
|----------------|---------|---------|--------------|---------------|------------------|--------|
| ci-management | 50 | -7623 | 9 | 9 | 2025-12-10 | ✅ |
| voltha-go | 29 | +234584 | 9 | 9 | 2025-12-10 | ✅ |
| voltha-openonu-adapter-go | 29 | +188670 | 8 | 7 | 2025-12-12 | ✅ |
| voltha-openolt-adapter | 25 | +453388 | 10 | 7 | 2025-12-12 | ✅ |
| voltha-system-tests | 18 | -293 | 5 | 181 | 2025-06-21 | ✅ |
| pod-configs | 16 | +78 | 4 | 2 | 2025-12-17 | ✅ |
| voltha-go-controller | 15 | +161405 | 8 | 7 | 2025-12-12 | ✅ |
| cord-charts-repo | 14 | +1412 | 1 | 7 | 2025-12-12 | ✅ |
| voltha-helm-charts | 13 | +389 | 5 | 9 | 2025-12-10 | ✅ |
| voltha-lib-go | 11 | +234497 | 6 | 50 | 2025-10-30 | ✅ |
| voltha-docs | 9 | +600 | 1 | 113 | 2025-08-28 | ✅ |
| aaa | 5 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| bng | 5 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| dhcpl2relay | 5 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| mcast | 5 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| olt | 5 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| pppoeagent | 5 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| voltha-docker-tools | 5 | +0 | 3 | 42 | 2025-11-07 | ✅ |
| voltctl | 4 | +49263 | 4 | 155 | 2025-07-17 | ✅ |
| device-management-interface | 3 | +11931 | 2 | 76 | 2025-10-04 | ✅ |
| kafka-onos | 3 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| mac-learning | 3 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| openolt | 3 | +643 | 3 | 171 | 2025-07-01 | ✅ |
| voltha-protos | 3 | +936 | 3 | 178 | 2025-06-24 | ✅ |
| bbsim | 2 | +1867 | 2 | 358 | 2024-12-26 | ✅ |
| bbsim-sadis-server | 2 | +0 | 2 | 335 | 2025-01-18 | ✅ |
| helm-repo-tools | 2 | -1 | 1 | 331 | 2025-01-22 | ✅ |
| igmpproxy | 2 | +0 | 1 | 336 | 2025-01-17 | ✅ |
| ofagent-go | 2 | +952 | 2 | 336 | 2025-01-17 | ✅ |
| sadis | 2 | +0 | 1 | 336 | 2025-01-17 | ✅ |
| cord-tester | 1 | -1 | 1 | 251 | 2025-04-12 | ✅ |
| omci-lib-go | 1 | +70 | 1 | 122 | 2025-08-19 | ✅ |
| .github | 0 | +0 | 0 | 461 | 2024-09-14 | ☑️ |
| ActiveTest | 0 | +0 | 0 | 3,059 | 2017-08-04 | 🛑 |
| Aether-Projects | 0 | +0 | 0 | 455 | 2024-09-20 | ☑️ |
| CORD-Projects | 0 | +0 | 0 | 455 | 2024-09-20 | ☑️ |
| Ignite | 0 | +0 | 0 | 2,115 | 2020-03-05 | 🛑 |
| Infra-Projects | 0 | +0 | 0 | 455 | 2024-09-20 | ☑️ |
| MME2 | 0 | +0 | 0 | 2,216 | 2019-11-25 | 🛑 |
| ONOS-App-projects | 0 | +0 | 0 | 455 | 2024-09-20 | ☑️ |
| PassiveTest | 0 | +0 | 0 | 3,059 | 2017-08-04 | 🛑 |
| PublicTest | 0 | +0 | 0 | 1,254 | 2022-07-14 | 🛑 |
| SDCore-Projects | 0 | +0 | 0 | 455 | 2024-09-20 | ☑️ |
| SDFabric-Projects | 0 | +0 | 0 | 455 | 2024-09-20 | ☑️ |
| VOLTHA-Projects | 0 | +0 | 0 | 391 | 2024-11-23 | ☑️ |
| acordion | 0 | +0 | 0 | 2,774 | 2018-05-16 | 🛑 |
| addressmanager | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| alpine-grpc-base | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| ansible/onf-ansible | 0 | +0 | 0 | 1,347 | 2022-04-12 | 🛑 |
| ansible/role/389ds | 0 | +0 | 0 | 1,563 | 2021-09-08 | 🛑 |
| ansible/role/acme | 0 | +0 | 0 | 1,247 | 2022-07-21 | 🛑 |
| ansible/role/apt_source | 0 | +0 | 0 | 1,466 | 2021-12-14 | 🛑 |
| ansible/role/bird | 0 | +0 | 0 | 1,361 | 2022-03-29 | 🛑 |
| ansible/role/chrony | 0 | +0 | 0 | 1,240 | 2022-07-28 | 🛑 |
| ansible/role/devtools | 0 | +0 | 0 | 1,272 | 2022-06-26 | 🛑 |
| ansible/role/dhcpd | 0 | +0 | 0 | 1,115 | 2022-11-30 | 🛑 |
| ansible/role/dkms | 0 | +0 | 0 | 1,416 | 2022-02-02 | 🛑 |
| ansible/role/docker | 0 | +0 | 0 | 1,315 | 2022-05-14 | 🛑 |
| ansible/role/ds389 | 0 | +0 | 0 | 1,202 | 2022-09-04 | 🛑 |
| ansible/role/edgemonagent | 0 | +0 | 0 | 1,724 | 2021-03-31 | 🛑 |
| ansible/role/enodebd | 0 | +0 | 0 | 1,202 | 2022-09-04 | 🛑 |
| ansible/role/gerrit | 0 | +0 | 0 | 1,202 | 2022-09-04 | 🛑 |
| ansible/role/golang | 0 | +0 | 0 | 1,282 | 2022-06-16 | 🛑 |
| ansible/role/jenkins | 0 | +0 | 0 | 1,868 | 2020-11-07 | 🛑 |
| ansible/role/keycloak | 0 | +0 | 0 | 1,202 | 2022-09-04 | 🛑 |
| ansible/role/lbackup | 0 | +0 | 0 | 1,858 | 2020-11-17 | 🛑 |
| ansible/role/lua | 0 | +0 | 0 | 1,498 | 2021-11-12 | 🛑 |
| ansible/role/mariadb | 0 | +0 | 0 | 1,202 | 2022-09-04 | 🛑 |
| ansible/role/netbox | 0 | +0 | 0 | 1,202 | 2022-09-04 | 🛑 |
| ansible/role/netprep | 0 | +0 | 0 | 1,543 | 2021-09-28 | 🛑 |
| ansible/role/nginx | 0 | +0 | 0 | 1,313 | 2022-05-16 | 🛑 |
| ansible/role/node_exporter | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/nodejs | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/nsd | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/onieboot | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/openvpn | 0 | +0 | 0 | 1,363 | 2022-03-27 | 🛑 |
| ansible/role/php | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/postgresql | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/proxmox | 0 | +0 | 0 | 1,430 | 2022-01-19 | 🛑 |
| ansible/role/pxeboot | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/qat | 0 | +0 | 0 | 1,375 | 2022-03-15 | 🛑 |
| ansible/role/rbackup | 0 | +0 | 0 | 1,858 | 2020-11-17 | 🛑 |
| ansible/role/redis | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/rke2 | 0 | +0 | 0 | 1,387 | 2022-03-03 | 🛑 |
| ansible/role/sriov | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/strongswan | 0 | +0 | 0 | 1,256 | 2022-07-12 | 🛑 |
| ansible/role/timesheets | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/unbound | 0 | +0 | 0 | 1,101 | 2022-12-14 | 🛑 |
| ansible/role/unifi | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/users | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| ansible/role/usrp | 0 | +0 | 0 | 1,200 | 2022-09-06 | 🛑 |
| asfvolt16-driver | 0 | +0 | 0 | 2,640 | 2018-09-27 | 🛑 |
| asfvolt16-onl | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| att-workflow-driver | 0 | +0 | 0 | 2,031 | 2020-05-28 | 🛑 |
| automation-tools | 0 | +0 | 0 | 1,913 | 2020-09-23 | 🛑 |
| carrierethernet | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cbrstools | 0 | +0 | 0 | 1,434 | 2022-01-15 | 🛑 |
| certification | 0 | +0 | 0 | 2,327 | 2019-08-06 | 🛑 |
| cggs | 0 | +0 | 0 | 752 | 2023-11-28 | ☑️ |
| chameleon | 0 | +0 | 0 | 2,128 | 2020-02-21 | 🛑 |
| comac-helm-charts | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| composer | 0 | +0 | 0 | 3,248 | 2017-01-27 | 🛑 |
| config | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cord | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cord-omec | 0 | +0 | 0 | 2,355 | 2019-07-09 | 🛑 |
| cord-onos-publisher | 0 | +0 | 0 | 2,164 | 2020-01-16 | 🛑 |
| cord-platform | 0 | +0 | 0 | 2,173 | 2020-01-07 | 🛑 |
| cord-service-boilerplate | 0 | +0 | 0 | 3,184 | 2017-04-01 | 🛑 |
| cord-workflow-airflow | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cord-workflow-controller | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cord-workflow-controller-client | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cord-workflow-probe | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| cordctl | 0 | +0 | 0 | 2,061 | 2020-04-28 | 🛑 |
| device-management | 0 | +0 | 0 | 1,704 | 2021-04-20 | 🛑 |
| docs | 0 | +0 | 0 | 1,675 | 2021-05-19 | 🛑 |
| dt-workflow-driver | 0 | +0 | 0 | 2,031 | 2020-05-28 | 🛑 |
| ecord | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| enodebd | 0 | +0 | 0 | 1,270 | 2022-06-28 | 🛑 |
| epc-service | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| exampleservice | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| fabric | 0 | +0 | 0 | 2,001 | 2020-06-27 | 🛑 |
| fabric-crossconnect | 0 | +0 | 0 | 2,004 | 2020-06-24 | 🛑 |
| fabric-oftest | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| fabric-tofino | 0 | +0 | 0 | 1,492 | 2021-11-18 | 🛑 |
| foo-app | 0 | +0 | 0 | 2,759 | 2018-05-31 | 🛑 |
| fpcagent | 0 | +0 | 0 | 2,827 | 2018-03-24 | 🛑 |
| freeDiameter-old | 0 | +0 | 0 | 2,719 | 2018-07-10 | 🛑 |
| fwaas | 0 | +0 | 0 | 2,876 | 2018-02-03 | 🛑 |
| globalxos | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| go-manifest | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| goloxi | 0 | +0 | 0 | 2,066 | 2020-04-23 | 🛑 |
| grpc-robot | 0 | +0 | 0 | 1,410 | 2022-02-08 | 🛑 |
| helm-charts | 0 | +0 | 0 | 1,201 | 2022-09-05 | 🛑 |
| hippie-oss | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| hss_db | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| hypercache | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| igmp | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| igmpca | 0 | +0 | 0 | 981 | 2023-04-13 | ☑️ |
| infra-containers | 0 | +0 | 0 | 1,562 | 2021-09-09 | 🛑 |
| infra-manifest | 0 | +0 | 0 | 1,247 | 2022-07-21 | 🛑 |
| internetemulator | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| ipxe-build | 0 | +0 | 0 | 1,310 | 2022-05-19 | 🛑 |
| k8sepcservice | 0 | +0 | 0 | 2,666 | 2018-09-01 | 🛑 |
| kafka-robot | 0 | +0 | 0 | 1,541 | 2021-09-30 | 🛑 |
| kafka-topic-exporter | 0 | +0 | 0 | 1,365 | 2022-03-25 | 🛑 |
| kafkaloghandler | 0 | +0 | 0 | 2,600 | 2018-11-06 | 🛑 |
| kolla | 0 | +0 | 0 | 2,956 | 2017-11-15 | 🛑 |
| kolla-ansible | 0 | +0 | 0 | 2,899 | 2018-01-11 | 🛑 |
| kubernetes-service | 0 | +0 | 0 | 2,088 | 2020-04-01 | 🛑 |
| lbaas | 0 | +0 | 0 | 2,982 | 2017-10-20 | 🛑 |
| maas | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| manifest | 0 | +0 | 0 | 2,165 | 2020-01-15 | 🛑 |
| mcord | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| mcord-configs | 0 | +0 | 0 | 2,876 | 2018-02-03 | 🛑 |
| metro-net | 0 | +0 | 0 | 3,024 | 2017-09-08 | 🛑 |
| metronet-local | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| mgmt-gateway-vm | 0 | +0 | 0 | 2,687 | 2018-08-11 | 🛑 |
| mn-stratum-siab | 0 | +0 | 0 | 2,222 | 2019-11-19 | 🛑 |
| monitoring | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| multifabric | 0 | +0 | 0 | 2,148 | 2020-02-01 | 🛑 |
| multistructlog | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| nem-ondemand-proxy | 0 | +0 | 0 | 2,099 | 2020-03-21 | 🛑 |
| network-diag-app | 0 | +0 | 0 | 1,060 | 2023-01-24 | ☑️ |
| ng-xos-lib | 0 | +0 | 0 | 3,054 | 2017-08-09 | 🛑 |
| ntt-workflow-driver | 0 | +0 | 0 | 1,738 | 2021-03-17 | 🛑 |
| olt-service | 0 | +0 | 0 | 2,088 | 2020-04-01 | 🛑 |
| olttopology | 0 | +0 | 0 | 690 | 2024-01-29 | ☑️ |
| omec-cni | 0 | +0 | 0 | 1,231 | 2022-08-06 | 🛑 |
| omec-pod-init | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| onf-docs | 0 | +0 | 0 | 1,385 | 2022-03-05 | 🛑 |
| onf-make | 0 | +0 | 0 | 423 | 2024-10-22 | ☑️ |
| onf-scripts | 0 | +0 | 0 | 477 | 2024-08-29 | ☑️ |
| onfca | 0 | +0 | 0 | 1,150 | 2022-10-26 | 🛑 |
| onos-classic-helm-utils | 0 | +0 | 0 | 1,610 | 2021-07-23 | 🛑 |
| onos-service | 0 | +0 | 0 | 2,088 | 2020-04-01 | 🛑 |
| openairinterface | 0 | +0 | 0 | 1,878 | 2020-10-28 | 🛑 |
| opencloud | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| opendevice-manager | 0 | +0 | 0 | 1,667 | 2021-05-27 | 🛑 |
| opendm-agent | 0 | +0 | 0 | 1,703 | 2021-04-21 | 🛑 |
| openolt-api | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| openolt-scale-tester | 0 | +0 | 0 | 1,631 | 2021-07-02 | 🛑 |
| openolt-test | 0 | +0 | 0 | 1,785 | 2021-01-29 | 🛑 |
| openomci | 0 | +0 | 0 | 2,927 | 2017-12-14 | 🛑 |
| openstack | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| osam | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| person-detection-app | 0 | +0 | 0 | 1,288 | 2022-06-10 | 🛑 |
| platform-install | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| plyxproto | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| pppoel2relay | 0 | +0 | 0 | 2,274 | 2019-09-28 | 🛑 |
| progran | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| pubsafe | 0 | +0 | 0 | 3,236 | 2017-02-08 | 🛑 |
| qa-manifest | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| quagga | 0 | +0 | 0 | 3,024 | 2017-09-08 | 🛑 |
| rcord | 0 | +0 | 0 | 2,024 | 2020-06-04 | 🛑 |
| redfish-agent | 0 | +0 | 0 | 2,635 | 2018-10-02 | 🛑 |
| repo | 0 | +0 | 0 | 2,530 | 2019-01-15 | 🛑 |
| roc-helm-charts | 0 | +0 | 0 | 940 | 2023-05-24 | ☑️ |
| sadis-server | 0 | +0 | 0 | 2,114 | 2020-03-06 | 🛑 |
| sdcore-docs | 0 | +0 | 0 | 811 | 2023-09-30 | ☑️ |
| sdcore-helm-charts | 0 | +0 | 0 | 938 | 2023-05-26 | ☑️ |
| sdfabric-docs | 0 | +0 | 0 | 1,221 | 2022-08-16 | 🛑 |
| sdfabric-helm-charts | 0 | +0 | 0 | 1,114 | 2022-12-01 | 🛑 |
| sdn-controller | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| seba | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| seba-manifest | 0 | +0 | 0 | 2,719 | 2018-07-10 | 🛑 |
| service-profile | 0 | +0 | 0 | 3,150 | 2017-05-05 | 🛑 |
| simpleexampleservice | 0 | +0 | 0 | 2,026 | 2020-06-02 | 🛑 |
| sjsg | 0 | +0 | 0 | 1,370 | 2022-03-20 | 🛑 |
| swarm | 0 | +0 | 0 | 2,985 | 2017-10-17 | 🛑 |
| templateservice | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| tt-workflow-driver | 0 | +0 | 0 | 2,100 | 2020-03-20 | 🛑 |
| vBBU | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vEE | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vEG | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vHSS | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vMM | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vMME | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vPGWC | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vPGWU | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vSGW | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vSGWU | 0 | +0 | 0 | 3,048 | 2017-08-15 | 🛑 |
| vSM | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| venb | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| ves-agent | 0 | +0 | 0 | 2,626 | 2018-10-11 | 🛑 |
| vnaas | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| voltha-adtran-adapter | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| voltha-api-server | 0 | +0 | 0 | 777 | 2023-11-03 | ☑️ |
| voltha-bal | 0 | +0 | 0 | 3,116 | 2017-06-08 | 🛑 |
| voltha-eponolt-adapter | 0 | +0 | 0 | 1,824 | 2020-12-21 | 🛑 |
| voltha-epononu-adapter | 0 | +0 | 0 | 1,824 | 2020-12-21 | 🛑 |
| voltha-northbound-bbf-adapter | 0 | +0 | 0 | 1,219 | 2022-08-18 | 🛑 |
| voltha-omci | 0 | +0 | 0 | 2,926 | 2017-12-15 | 🛑 |
| voltha-onos | 0 | +0 | 0 | 596 | 2024-05-02 | ☑️ |
| voltha-release | 0 | +0 | 0 | 684 | 2024-02-04 | ☑️ |
| voltha-test-manifest | 0 | +0 | 0 | 2,059 | 2020-04-30 | 🛑 |
| vrouter | 0 | +0 | 0 | 2,088 | 2020-04-01 | 🛑 |
| vsg | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vsg-hw | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vspgwc | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vspgwu | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vtn | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vtn-service | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| vtr | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| xRAN | 0 | +0 | 0 | 3,103 | 2017-06-21 | 🛑 |
| xos | 0 | +0 | 0 | 1,982 | 2020-07-16 | 🛑 |
| xos-external-app-examples | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| xos-gui | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| xos-manifest | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| xos-rest-gw | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| xos-sample-gui-extension | 0 | +0 | 0 | 2,218 | 2019-11-23 | 🛑 |
| xos-tosca | 0 | +0 | 0 | 2,128 | 2020-02-21 | 🛑 |
| xran-controller | 0 | +0 | 0 | 2,934 | 2017-12-07 | 🛑 |

**Total:** 252 repositories

## 📝 Gerrit Projects with No Apparent Commits

**WARNING:** All Gerrit projects/repositories should contain at least one commit, due to the initial repository creation automation writing initial template and configuration files. The report generation and parsing logic may need checking/debugging for the projects/repositories below.

| Gerrit Project |
|------------|
| bogus-project |
| onos-robot |

**Total:** 2 Gerrit projects with no apparent commits

## 🔧 Gerrit Project Feature Matrix

| Gerrit Project | Type | Dependabot | Pre-commit | ReadTheDocs | .gitreview | G2G | Status |
|------------|------|------------|------------|-------------|------------|-----|--------|
| ci-management | jjb | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| voltha-go | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-openonu-adapter-go | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-openolt-adapter | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-system-tests | Robot Framework | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| pod-configs | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| voltha-go-controller | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| cord-charts-repo | None | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| voltha-helm-charts | Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| voltha-lib-go | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| voltha-docs | Python | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| aaa | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| bng | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| dhcpl2relay | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| mcast | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| olt | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| pppoeagent | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| voltha-docker-tools | None | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| voltctl | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| device-management-interface | Python | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| kafka-onos | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| mac-learning | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| openolt | C | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| voltha-protos | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| helm-repo-tools | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| bbsim | Go | ❌ | ✅ | ❌ | ✅ | ❌ | ✅ |
| igmpproxy | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| bbsim-sadis-server | Go | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| ofagent-go | Go | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| sadis | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| cord-tester | Robot Framework | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| omci-lib-go | Go | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ |
| ansible/role/apt_source | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/389ds | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/acme | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/devtools | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/chrony | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/dkms | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/bird | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/dhcpd | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/ds389 | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/docker | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/enodebd | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/gerrit | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/golang | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/edgemonagent | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/jenkins | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/keycloak | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/lbackup | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/lua | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/netprep | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/mariadb | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/netbox | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/nginx | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/nodejs | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/node_exporter | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/onieboot | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/nsd | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/qat | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/rbackup | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/php | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/openvpn | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/postgresql | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/proxmox | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/pxeboot | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/redis | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/rke2 | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ansible/role/sriov | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/timesheets | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/unifi | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/strongswan | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/users | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/unbound | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ansible/role/usrp | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| Aether-Projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| .github | None | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| CORD-Projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| Infra-Projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| Ignite | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| MME2 | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ONOS-App-projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| PublicTest | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| SDCore-Projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| SDFabric-Projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| VOLTHA-Projects | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| ansible/onf-ansible | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ActiveTest | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| acordion | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| PassiveTest | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| alpine-grpc-base | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| addressmanager | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| asfvolt16-onl | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| asfvolt16-driver | C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| att-workflow-driver | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| bogus-project | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| cbrstools | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cggs | Python | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| certification | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| chameleon | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| comac-helm-charts | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| automation-tools | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| composer | JavaScript | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| config | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-omec | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| cord-onos-publisher | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-platform | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-service-boilerplate | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| carrierethernet | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-airflow | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-controller | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-controller-client | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| cord-workflow-probe | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| dt-workflow-driver | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| docs | Ruby | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ecord | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| epc-service | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| exampleservice | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fabric | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fabric-crossconnect | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| enodebd | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| foo-app | Java/Maven | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| fpcagent | Java | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| cordctl | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fwaas | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| fabric-oftest | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| globalxos | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| go-manifest | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| goloxi | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| grpc-robot | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| hippie-oss | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| hss_db | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| igmp | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| hypercache | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| igmpca | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| freeDiameter-old | C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| infra-manifest | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| infra-containers | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| internetemulator | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| fabric-tofino | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ipxe-build | Dockerfile | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| k8sepcservice | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kafka-robot | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| kolla | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kafkaloghandler | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kolla-ansible | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| lbaas | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| kubernetes-service | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| manifest | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| mcord-configs | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| mcord | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| helm-charts | Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| mgmt-gateway-vm | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| mn-stratum-siab | Dockerfile | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| metro-net | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| metronet-local | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| multifabric | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| multistructlog | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| network-diag-app | Python | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| ntt-workflow-driver | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| ng-xos-lib | JavaScript | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| monitoring | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| olt-service | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| device-management | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| olttopology | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| omec-cni | Dockerfile | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| omec-pod-init | Dockerfile | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onf-docs | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| onos-classic-helm-utils | Dockerfile | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onf-scripts | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| onfca | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| onos-robot | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openairinterface | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| maas | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onos-service | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opencloud | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opendm-agent | C++ | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openolt-api | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| onf-make | Python | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| kafka-topic-exporter | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| nem-ondemand-proxy | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| openolt-test | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openomci | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| openstack | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| person-detection-app | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| plyxproto | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| pppoel2relay | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| progran | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| pubsafe | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| qa-manifest | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| redfish-agent | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| rcord | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| repo | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| sdcore-docs | Python | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| quagga | C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| roc-helm-charts | Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| sadis-server | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdn-controller | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdfabric-docs | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| openolt-scale-tester | Go | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| sdfabric-helm-charts | Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sdcore-helm-charts | Smarty | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| seba | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| seba-manifest | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| platform-install | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| sjsg | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| swarm | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| simpleexampleservice | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| templateservice | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| opendevice-manager | Go | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| osam | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| tt-workflow-driver | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vBBU | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vMM | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vEE | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vHSS | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vEG | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vMME | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vPGWU | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vPGWC | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vSGWU | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| vSGW | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vSM | None | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| service-profile | Shell | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| venb | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| ves-agent | Java/Maven | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| vnaas | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltha-adtran-adapter | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltha-bal | C | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-eponolt-adapter | Go | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-omci | Python | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-epononu-adapter | Go | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| voltha-onos | Shell | ❌ | ✅ | ❌ | ✅ | ❌ | ☑️ |
| voltha-api-server | Go | ❌ | ❌ | ❌ | ✅ | ❌ | ☑️ |
| voltha-release | None | ❌ | ❌ | ❌ | ❌ | ❌ | ☑️ |
| voltha-test-manifest | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| voltha-northbound-bbf-adapter | Go | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vrouter | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vsg-hw | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vsg | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vspgwc | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vspgwu | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vtn-service | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| vtr | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xRAN | None | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| vtn | Java/Maven | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-manifest | Shell | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-rest-gw | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-sample-gui-extension | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-external-app-examples | JavaScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-tosca | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xos-gui | TypeScript | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |
| xran-controller | Java | ❌ | ❌ | ❌ | ❌ | ❌ | 🛑 |
| xos | Python | ❌ | ❌ | ❌ | ✅ | ❌ | 🛑 |

## 🏁 Deployed CI/CD Jobs

**Total GitHub workflows:** 3
**Total Jenkins jobs:** 6

| Gerrit Project | GitHub Workflows | Workflow Count | Jenkins Jobs | Job Count |
|----------------|-------------------|----------------|--------------|-----------|
| ci-management | <a href="https://github.com/lfbroadband/ci-management/actions/workflows/call-github2gerrit.yaml" target="_blank"><span class="status-unknown workflow-status">call-github2gerrit.yaml</span></a><br><a href="https://github.com/lfbroadband/ci-management/actions/workflows/gerrit-merge.yaml" target="_blank"><span class="status-unknown workflow-status">gerrit-merge.yaml</span></a><br><a href="https://github.com/lfbroadband/ci-management/actions/workflows/gerrit-verify.yaml" target="_blank"><span class="status-unknown workflow-status">gerrit-verify.yaml</span></a> | 3 | <a href="https://jenkins.lfbroadband.org/job/ci-management-ami-packer-merge-ubuntu-18.04-basebuild_1804/" target="_blank"><span class="status-failure jenkins-status">ci-management-ami-packer-merge-ubuntu-18.04-basebuild_1804</span></a><br><a href="https://jenkins.lfbroadband.org/job/ci-management-ami-packer-verify/" target="_blank"><span class="status-warning jenkins-status">ci-management-ami-packer-verify</span></a><br><a href="https://jenkins.lfbroadband.org/job/ci-management-ami-packer-verify-build-ubuntu-18.04-basebuild_1804/" target="_blank"><span class="status-success jenkins-status">ci-management-ami-packer-verify-build-ubuntu-18.04-basebuild_1804</span></a> | 3 |
| onf-make |  | 0 | <a href="https://jenkins.lfbroadband.org/job/onf-make-unit-test-bbsim/" target="_blank"><span class="status-success jenkins-status">onf-make-unit-test-bbsim</span></a><br><a href="https://jenkins.lfbroadband.org/job/onf-make-voltha-dt-fttb-test-bbsim-master/" target="_blank"><span class="status-success jenkins-status">onf-make-voltha-dt-fttb-test-bbsim-master</span></a><br><a href="https://jenkins.lfbroadband.org/job/onf-make-voltha-sanity-test-multi-runs/" target="_blank"><span class="status-success jenkins-status">onf-make-voltha-sanity-test-multi-runs</span></a> | 3 |

**Total:** 2 repositories with CI/CD jobs

### ⏭️ Unallocated Jenkins jobs

The Jenkins jobs below could not be directly attributed to a specific Gerrit project.

**Note:** this table may change over time, as improvements are made to the matching heuristics.

**Total unallocated Jenkins jobs:** 193

| Jenkins job |
|-------------|
| bbsim_scale_test |
| build_berlin-community-pod-1-gpon-adtran_1T8GEM_DT_voltha_master |
| build_berlin-community-pod-1-gpon-adtran_1T8GEM_voltha_DT_master_test |
| build_berlin-community-pod-1-gpon_1T8GEM_DT_voltha_master |
| build_berlin-community-pod-1-gpon_1T8GEM_voltha_DT_master_test |
| build_berlin-community-pod-1-gpon_TP_TT_voltha_master |
| build_berlin-community-pod-1-gpon_TP_voltha_TT_master_test |
| build_berlin-community-pod-1-multi-olt_1T8GEM_DT_voltha_master |
| build_berlin-community-pod-1-multi-olt_1T8GEM_voltha_DT_master_test |
| build_berlin-community-pod-2-gpon-zyxel_1T8GEM_DT_voltha_master |
| build_berlin-community-pod-2-gpon-zyxel_1T8GEM_voltha_DT_master_test |
| build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_DT_voltha_master |
| build_berlin-community-pod-2-xgspon-zyxel_1T8GEM_voltha_DT_master_test |
| build_berlin-community-pod-2-xgspon-zyxel_TP_TT_voltha_master |
| build_berlin-community-pod-2-xgspon-zyxel_TP_voltha_TT_master_test |
| check_infrastructure |
| docker-publish_bbsim |
| docker-publish_bbsim-sadis-server |
| docker-publish_ofagent-go |
| docker-publish_voltha-docker-tools |
| docker-publish_voltha-go |
| docker-publish_voltha-go-controller |
| docker-publish_voltha-onos |
| docker-publish_voltha-openolt-adapter |
| docker-publish_voltha-openonu-adapter-go |
| github-release_bbsim |
| github-release_voltctl |
| helm-lint_voltha-helm-charts |
| maven-publish_aaa |
| maven-publish_bng |
| maven-publish_dhcpl2relay |
| maven-publish_igmpproxy |
| maven-publish_kafka-onos |
| maven-publish_mac-learning |
| maven-publish_mcast |
| maven-publish_olt |
| maven-publish_pppoeagent |
| maven-publish_sadis |
| onos-app-release |
| patchset-voltha-2.14-multiple-olts-openonu-go-test-bbsim |
| patchset-voltha-2.14-openonu-go-test-bbsim |
| patchset-voltha-multiple-olts-openonu-go-test-bbsim |
| patchset-voltha-multiple-olts-pm-data-test-bbsim |
| patchset-voltha-openonu-go-test-bbsim |
| patchset-voltha-pm-data-test-bbsim |
| periodic-software-upgrade-test-bbsim |
| periodic-software-upgrade-test-bbsim-2.11 |
| periodic-software-upgrade-test-bbsim-2.14 |
| periodic-voltha-combined-vgc |
| periodic-voltha-combined-vgc-multi-olt |
| periodic-voltha-dt-fttb-test-bbsim-2.14 |
| periodic-voltha-dt-fttb-test-bbsim-master |
| periodic-voltha-dt-test-bbsim-2.14 |
| periodic-voltha-dt-test-bbsim-master |
| periodic-voltha-etcd-test |
| periodic-voltha-etcd-test-2.14 |
| periodic-voltha-memory-leak-test-bbsim |
| periodic-voltha-memory-leak-test-bbsim-2.14 |
| periodic-voltha-multi-uni-multiple-olts-test-bbsim |
| periodic-voltha-multi-uni-multiple-olts-test-bbsim-2.14 |
| periodic-voltha-multi-uni-test-bbsim |
| periodic-voltha-multi-uni-test-bbsim-2.14 |
| periodic-voltha-multiple-olts-openonu-go-test-bbsim |
| periodic-voltha-multiple-olts-openonu-go-test-bbsim-2.14 |
| periodic-voltha-multiple-olts-pm-data-test-bbsim |
| periodic-voltha-multiple-olts-pm-data-test-bbsim-2.14 |
| periodic-voltha-multiple-olts-test-bbsim |
| periodic-voltha-multiple-olts-test-bbsim-2.14 |
| periodic-voltha-openonu-go-test-bbsim |
| periodic-voltha-openonu-go-test-bbsim-2.14 |
| periodic-voltha-pm-data-test-bbsim |
| periodic-voltha-pm-data-test-bbsim-2.14 |
| periodic-voltha-sanity-test-multi-runs |
| periodic-voltha-test-DMI |
| periodic-voltha-test-DMI-2.14 |
| periodic-voltha-test-bbsim |
| periodic-voltha-test-bbsim-2.14 |
| periodic-voltha-tim-multiple-olts-test-bbsim |
| periodic-voltha-tt-maclearner-sanity-test-bbsim |
| periodic-voltha-unitag-subscriber-tt-test-bbsim |
| periodic-voltha-unitag-subscriber-tt-test-bbsim-2.14 |
| publish-helm-repo_voltha-helm-charts |
| pypi-publish_device-management-interface |
| pypi-publish_voltha-protos |
| sync-dir_voltha-docs |
| tag-check_voltha-docs |
| tag-check_voltha-helm-charts |
| verify_aaa_licensed |
| verify_aaa_maven-test |
| verify_bbsim-sadis-server_licensed |
| verify_bbsim-sadis-server_sanity-test |
| verify_bbsim-sadis-server_sanity-test-voltha-2.14 |
| verify_bbsim-sadis-server_unit-test |
| verify_bbsim_licensed |
| verify_bbsim_sanity-test |
| verify_bbsim_sanity-test-voltha-2.14 |
| verify_bbsim_unit-test |
| verify_berlin-community-pod-1-gpon-adtran_Default_DT_voltha_master_dmi |
| verify_bng_licensed |
| verify_bng_maven-test |
| verify_device-management-interface_licensed |
| verify_device-management-interface_unit-test |
| verify_dhcpl2relay_licensed |
| verify_dhcpl2relay_maven-test |
| verify_helm-repo-tools_licensed |
| verify_helm-repo-tools_shellcheck |
| verify_igmpproxy_licensed |
| verify_igmpproxy_maven-test |
| verify_kafka-onos_licensed |
| verify_kafka-onos_maven-test |
| verify_mac-learning_licensed |
| verify_mac-learning_maven-test |
| verify_mcast_licensed |
| verify_mcast_maven-test |
| verify_ofagent-go_licensed |
| verify_ofagent-go_sanity-test |
| verify_ofagent-go_sanity-test-voltha-2.14 |
| verify_ofagent-go_unit-test |
| verify_olt_licensed |
| verify_olt_maven-test |
| verify_omci-lib-go_licensed |
| verify_omci-lib-go_unit-test |
| verify_openolt_licensed |
| verify_openolt_unit-test |
| verify_pppoeagent_licensed |
| verify_pppoeagent_maven-test |
| verify_sadis_licensed |
| verify_sadis_maven-test |
| verify_voltctl_licensed |
| verify_voltctl_sanity-test |
| verify_voltctl_unit-test |
| verify_voltha-docker-tools_licensed |
| verify_voltha-docker-tools_unit-test |
| verify_voltha-docs_licensed |
| verify_voltha-docs_unit-test |
| verify_voltha-go-controller_licensed |
| verify_voltha-go-controller_unit-test |
| verify_voltha-go_licensed |
| verify_voltha-go_sanity-test |
| verify_voltha-go_sanity-test-voltha-2.14 |
| verify_voltha-go_unit-test-lint |
| verify_voltha-go_unit-test-tests |
| verify_voltha-helm-charts_licensed |
| verify_voltha-helm-charts_sanity-test |
| verify_voltha-helm-charts_sanity-test-voltha-2.14 |
| verify_voltha-lib-go_licensed |
| verify_voltha-lib-go_unit-test |
| verify_voltha-onos_licensed |
| verify_voltha-onos_sanity-test |
| verify_voltha-onos_sanity-test-voltha-2.14 |
| verify_voltha-onos_unit-test |
| verify_voltha-openolt-adapter_licensed |
| verify_voltha-openolt-adapter_sanity-test |
| verify_voltha-openolt-adapter_sanity-test-voltha-2.14 |
| verify_voltha-openolt-adapter_unit-test-lint |
| verify_voltha-openolt-adapter_unit-test-tests |
| verify_voltha-openonu-adapter-go_licensed |
| verify_voltha-openonu-adapter-go_sanity-test |
| verify_voltha-openonu-adapter-go_sanity-test-voltha-2.14 |
| verify_voltha-openonu-adapter-go_unit-test-lint |
| verify_voltha-openonu-adapter-go_unit-test-tests |
| verify_voltha-protos_licensed |
| verify_voltha-protos_unit-test |
| verify_voltha-system-tests_licensed |
| verify_voltha-system-tests_sanity-test |
| verify_voltha-system-tests_sanity-test-py312 |
| verify_voltha-system-tests_sanity-test-voltha-2.14 |
| verify_voltha-system-tests_unit-test |
| version-tag_voltha-docs |
| version-tag_voltha-helm-charts |
| version-tag_wildcard |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-dt-subscribers |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-tt-subscribers |
| voltha-scale-measurements-lwc-dt-256 |
| voltha-scale-measurements-lwc-dt-512 |
| voltha-scale-measurements-master-1-64-63-dt-subscribers |
| voltha-scale-measurements-master-1-64-63-tt-subscribers |
| voltha-scale-measurements-master-10-stacks-2-16-32-att-subscribers |
| voltha-scale-measurements-master-10-stacks-2-16-32-dt-subscribers |
| voltha-scale-measurements-master-10-stacks-2-16-32-tt-subscribers |
| voltha-scale-measurements-master-2-16-32-att-subscribers |
| voltha-scale-measurements-master-2-16-32-dt-subscribers |
| voltha-scale-measurements-master-2-16-32-tt-subscribers |
| voltha-scale-measurements-master-2-16-32-tt-subscribers-maclearner |
| voltha-scale-measurements-master-2-64-32-dt-subscribers |
| voltha-scale-measurements-master-experimental |
| voltha-scale-measurements-master-experimental-multi-stack |
| voltha-scale-measurements-master-onu-upgrade-2-16-32-att-onus |
| voltha-scale-measurements-patchset-1-16-32-att-subscribers |
| voltha-scale-measurements-patchset-1-16-32-dt-subscribers |
| voltha-scale-measurements-patchset-1-16-32-tt-subscribers |
| voltha-scale-measurements-voltha-2.14-2-16-32-dt-subscribers |
| voltha-scale-measurements-voltha-2.14-2-16-32-tt-subscribers |

## 🏚️ Orphaned Jenkins Jobs

**Total Orphaned Jobs:** 22

These Jenkins jobs belong to archived or read-only Gerrit projects; audit them and consider removal.

| Job Name | Gerrit Project |
|----------|----------------|
| voltha-scale-measurements-master-experimental-multi-stack | voltha |
| voltha-scale-measurements-voltha-2.14-2-16-32-tt-subscribers | voltha |
| voltha-scale-measurements-master-1-64-63-dt-subscribers | voltha |
| voltha-scale-measurements-master-experimental | voltha |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-tt-subscribers | voltha |
| voltha-scale-measurements-2.14-10-stacks-2-16-32-dt-subscribers | voltha |
| voltha-scale-measurements-lwc-dt-512 | voltha |
| voltha-scale-measurements-master-2-16-32-att-subscribers | voltha |
| voltha-scale-measurements-master-2-64-32-dt-subscribers | voltha |
| voltha-scale-measurements-master-1-64-63-tt-subscribers | voltha |
| voltha-scale-measurements-voltha-2.14-2-16-32-dt-subscribers | voltha |
| voltha-scale-measurements-master-onu-upgrade-2-16-32-att-onus | voltha |
| voltha-scale-measurements-patchset-1-16-32-att-subscribers | voltha |
| voltha-scale-measurements-master-2-16-32-dt-subscribers | voltha |
| voltha-scale-measurements-lwc-dt-256 | voltha |
| voltha-scale-measurements-master-10-stacks-2-16-32-tt-subscribers | voltha |
| voltha-scale-measurements-patchset-1-16-32-dt-subscribers | voltha |
| voltha-scale-measurements-master-10-stacks-2-16-32-att-subscribers | voltha |
| voltha-scale-measurements-master-2-16-32-tt-subscribers | voltha |
| voltha-scale-measurements-patchset-1-16-32-tt-subscribers | voltha |
| voltha-scale-measurements-master-2-16-32-tt-subscribers-maclearner | voltha |
| voltha-scale-measurements-master-10-stacks-2-16-32-dt-subscribers | voltha |

**Recommendation:** review these jobs and remove them if they are no longer needed.


Generated with ❤️ by Release Engineering